import Foundation
import React
import Security
import UIKit
import UserNotifications

/**
 * The part of push that has to exist before JavaScript does. Call `start()` in
 * `didFinishLaunchingWithOptions`, before React Native starts, and forward the two
 * `didRegisterForRemoteNotifications` callbacks from the AppDelegate: iOS delivers the tap that
 * launched the app only to a delegate set before launching finishes.
 *
 * A library that sets itself as delegate later (Notifee) keeps this one and forwards what is not its own.
 */
@objc public final class KrontelliBarePush: NSObject, UNUserNotificationCenterDelegate {
  @objc public static let shared = KrontelliBarePush()

  fileprivate weak var module: KrontelliBare?
  fileprivate var token: String?
  fileprivate var tokenWaiters: [(String?, Error?) -> Void] = []
  fileprivate var pendingOpened: [String: Any]?
  private let lock = NSLock()

  @objc public func start() {
    UNUserNotificationCenter.current().delegate = self
  }

  @objc public func didRegister(deviceToken: Data) {
    let hex = deviceToken.map { String(format: "%02x", $0) }.joined()
    lock.lock()
    let changed = hex != token
    token = hex
    let waiters = tokenWaiters
    tokenWaiters = []
    lock.unlock()
    waiters.forEach { $0(hex, nil) }
    if changed { module?.emit("KrontelliToken", ["token": hex]) }
  }

  @objc public func didFailToRegister(error: Error) {
    lock.lock()
    let waiters = tokenWaiters
    tokenWaiters = []
    lock.unlock()
    waiters.forEach { $0(nil, error) }
  }

  fileprivate func requestToken(_ done: @escaping (String?, Error?) -> Void) {
    lock.lock()
    tokenWaiters.append(done)
    lock.unlock()
    DispatchQueue.main.async { UIApplication.shared.registerForRemoteNotifications() }
  }

  fileprivate func takePendingOpened() -> [String: Any]? {
    lock.lock()
    defer { lock.unlock() }
    let opened = pendingOpened
    pendingOpened = nil
    return opened
  }

  public func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                     withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
    if notification.request.trigger is UNPushNotificationTrigger {
      module?.emit("KrontelliReceived", ["data": Self.dataMap(notification.request.content.userInfo)])
    }
    completionHandler([.banner, .list, .sound, .badge])
  }

  public func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                     withCompletionHandler completionHandler: @escaping () -> Void) {
    defer { completionHandler() }
    guard response.notification.request.trigger is UNPushNotificationTrigger,
          response.actionIdentifier == UNNotificationDefaultActionIdentifier else { return }
    let data = Self.dataMap(response.notification.request.content.userInfo)
    if let module, module.hasListeners {
      module.emit("KrontelliOpened", ["data": data])
    } else {
      lock.lock()
      pendingOpened = data
      lock.unlock()
    }
  }

  private static func dataMap(_ userInfo: [AnyHashable: Any]) -> [String: Any] {
    var out: [String: Any] = [:]
    for (key, value) in userInfo {
      if let key = key as? String { out[key] = value }
    }
    return out
  }
}

@objc(KrontelliBare)
final class KrontelliBare: RCTEventEmitter {
  fileprivate var hasListeners = false
  private let defaults = UserDefaults.standard
  private static let service = "krontelli.bare"

  override init() {
    super.init()
    KrontelliBarePush.shared.module = self
  }

  override static func requiresMainQueueSetup() -> Bool { false }
  override func constantsToExport() -> [AnyHashable: Any]! {
    ["appVersion": Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") ?? ""]
  }

  override func supportedEvents() -> [String]! { ["KrontelliToken", "KrontelliReceived", "KrontelliOpened"] }
  override func startObserving() { hasListeners = true }
  override func stopObserving() { hasListeners = false }

  fileprivate func emit(_ name: String, _ body: [String: Any]) {
    if hasListeners { sendEvent(withName: name, body: body) }
  }

  private static func permission(_ status: UNAuthorizationStatus) -> String {
    switch status {
    case .authorized: return "granted"
    case .denied: return "denied"
    case .provisional, .ephemeral: return "provisional"
    default: return "undetermined"
    }
  }

  @objc(getPermission:rejecter:)
  func getPermission(_ resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    UNUserNotificationCenter.current().getNotificationSettings { resolve(Self.permission($0.authorizationStatus)) }
  }

  @objc(requestPermission:rejecter:)
  func requestPermission(_ resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, error in
      if let error { reject("permission", error.localizedDescription, error); return }
      UNUserNotificationCenter.current().getNotificationSettings { resolve(Self.permission($0.authorizationStatus)) }
    }
  }

  @objc(getDevicePushToken:rejecter:)
  func getDevicePushToken(_ resolve: @escaping RCTPromiseResolveBlock, rejecter reject: @escaping RCTPromiseRejectBlock) {
    KrontelliBarePush.shared.requestToken { token, error in
      if let token { resolve(token) } else { reject("token", error?.localizedDescription ?? "no token", error) }
    }
  }

  @objc(getLastNotificationResponse:rejecter:)
  func getLastNotificationResponse(_ resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    resolve(KrontelliBarePush.shared.takePendingOpened())
  }

  /// Android only; iOS has no channels.
  @objc(createChannel:name:)
  func createChannel(_ id: String, name: String) {}

  private func keychainQuery(_ key: String) -> [String: Any] {
    [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: Self.service, kSecAttrAccount as String: key]
  }

  @objc(secureGet:resolver:rejecter:)
  func secureGet(_ key: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    var query = keychainQuery(key)
    query[kSecReturnData as String] = true
    query[kSecMatchLimit as String] = kSecMatchLimitOne
    var item: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &item)
    if status == errSecItemNotFound { resolve(nil); return }
    guard status == errSecSuccess, let data = item as? Data else {
      reject("keychain", "read failed: \(status)", nil)
      return
    }
    resolve(String(data: data, encoding: .utf8))
  }

  @objc(secureSet:value:resolver:rejecter:)
  func secureSet(_ key: String, value: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    let query = keychainQuery(key)
    let attributes: [String: Any] = [
      kSecValueData as String: Data(value.utf8),
      kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly,
    ]
    var status = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
    if status == errSecItemNotFound {
      status = SecItemAdd(query.merging(attributes) { $1 } as CFDictionary, nil)
    }
    if status == errSecSuccess { resolve(nil) } else { reject("keychain", "write failed: \(status)", nil) }
  }

  @objc(secureRemove:resolver:rejecter:)
  func secureRemove(_ key: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    let status = SecItemDelete(keychainQuery(key) as CFDictionary)
    if status == errSecSuccess || status == errSecItemNotFound { resolve(nil) } else { reject("keychain", "delete failed: \(status)", nil) }
  }

  @objc(plainGet:resolver:rejecter:)
  func plainGet(_ key: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    resolve(defaults.string(forKey: key))
  }

  @objc(plainSet:value:resolver:rejecter:)
  func plainSet(_ key: String, value: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    defaults.set(value, forKey: key)
    resolve(nil)
  }

  @objc(plainRemove:resolver:rejecter:)
  func plainRemove(_ key: String, resolver resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    defaults.removeObject(forKey: key)
    resolve(nil)
  }
}
