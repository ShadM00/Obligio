require "json"

package = JSON.parse(File.read(File.join(__dir__, "package.json")))

Pod::Spec.new do |s|
  s.name         = "KrontelliBare"
  s.version      = package["version"]
  s.summary      = package["description"]
  s.license      = package["license"]
  s.homepage     = "https://krontelli.com"
  s.author       = "Krontelli"
  s.platforms    = { :ios => "15.1" }
  s.source       = { :git => "https://krontelli.com/sdk.git", :tag => s.version.to_s }
  s.source_files = "ios/**/*.{h,m,mm,swift}"
  s.swift_version = "5.0"
  s.pod_target_xcconfig = { "DEFINES_MODULE" => "YES" }
  install_modules_dependencies(s)
end
