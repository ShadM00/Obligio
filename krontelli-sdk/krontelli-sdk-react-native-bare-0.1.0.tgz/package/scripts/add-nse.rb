#!/usr/bin/env ruby
# Adds the KrontelliNSE notification service extension to a bare React Native Xcode project: receipts and rich media.
# The Expo plugin does this at prebuild; a committed project needs it once.
#
#   bundle exec ruby node_modules/@krontelli/sdk-react-native-bare/scripts/add-nse.rb \
#     --project ios/App.xcodeproj --app-target App --sdk node_modules/@krontelli/sdk-react-native
#
# Copies the extension sources next to the project, adds the target, embeds it in the app ahead of any script phase
# (Crashlytics' symbol step after an embed phase is a build cycle), and copies signing settings from the app target.
require "optparse"
require "fileutils"
require "xcodeproj"

NSE = "KrontelliNSE"
opts = { api: "https://api.krontelli.com" }
OptionParser.new do |o|
  o.on("--project PATH") { |v| opts[:project] = v }
  o.on("--app-target NAME") { |v| opts[:target] = v }
  o.on("--sdk PATH") { |v| opts[:sdk] = v }
  o.on("--api URL") { |v| opts[:api] = v }
end.parse!

project = Xcodeproj::Project.open(opts.fetch(:project))
app = project.targets.find { |t| t.name == opts.fetch(:target) } or abort("no target #{opts[:target]}")
abort("#{NSE} is already in the project") if project.targets.any? { |t| t.name == NSE }

dir = File.join(File.dirname(opts[:project]), NSE)
FileUtils.mkdir_p(dir)
swift = File.read(File.join(opts.fetch(:sdk), "plugin/nse/NotificationService.swift")).gsub("__KRONTELLI_API_BASE_URL__", opts[:api])
swift = swift.sub(/\/\/  KrontelliNSE — generated.*?\n\/\/  change the plugin props.*?\n/m, "//  KrontelliNSE, added by @krontelli/sdk-react-native-bare's add-nse.rb.\n")
File.write(File.join(dir, "NotificationService.swift"), swift)
plist = File.read(File.join(opts[:sdk], "plugin/nse/Info.plist"))
  .gsub("__KRONTELLI_APP_VERSION__", "$(MARKETING_VERSION)")
  .gsub("__KRONTELLI_BUILD_NUMBER__", "$(CURRENT_PROJECT_VERSION)")
File.write(File.join(dir, "Info.plist"), plist)

deployment = app.build_configurations.first.resolve_build_setting("IPHONEOS_DEPLOYMENT_TARGET") || "15.1"
target = project.new_target(:app_extension, NSE, :ios, deployment)
group = project.main_group.new_group(NSE, NSE)
target.add_file_references([group.new_file("NotificationService.swift")])
group.new_file("Info.plist")

target.build_configurations.each do |config|
  from = app.build_configurations.find { |c| c.name == config.name }
  bundle_id = from.resolve_build_setting("PRODUCT_BUNDLE_IDENTIFIER")
  config.build_settings.merge!(
    "PRODUCT_BUNDLE_IDENTIFIER" => "#{bundle_id}.#{NSE}",
    "PRODUCT_NAME" => "$(TARGET_NAME)",
    "INFOPLIST_FILE" => "#{NSE}/Info.plist",
    "SWIFT_VERSION" => "5.0",
    "TARGETED_DEVICE_FAMILY" => "1,2",
    "SKIP_INSTALL" => "YES",
    "GENERATE_INFOPLIST_FILE" => "NO",
    "LD_RUNPATH_SEARCH_PATHS" => ["$(inherited)", "@executable_path/Frameworks", "@executable_path/../../Frameworks"],
    "DEVELOPMENT_TEAM" => from.resolve_build_setting("DEVELOPMENT_TEAM"),
    "CODE_SIGN_STYLE" => from.resolve_build_setting("CODE_SIGN_STYLE") || "Automatic",
    "MARKETING_VERSION" => from.resolve_build_setting("MARKETING_VERSION"),
    "CURRENT_PROJECT_VERSION" => from.resolve_build_setting("CURRENT_PROJECT_VERSION"),
  )
end

embed = app.new_copy_files_build_phase("Embed Foundation Extensions")
embed.symbol_dst_subfolder_spec = :plug_ins
build_file = embed.add_file_reference(target.product_reference, true)
build_file.settings = { "ATTRIBUTES" => ["RemoveHeadersOnCopy"] }
app.add_dependency(target)
# Right after the Frameworks phase, ahead of every script.
phases = app.build_phases
phases.delete(embed)
phases.insert(phases.index(app.frameworks_build_phase) + 1, embed)
project.save
puts "Added #{NSE} to #{opts[:project]}"
