/**
 * The platform adapter for React Native apps without Expo. Pass it to the SDK:
 *
 *   Krontelli.init({ ..., platform: createBarePlatform({ appVersion, androidChannel: { id, name } }) });
 *
 * Tokens, permission, taps and storage come from this package's own small native module, so the app
 * needs no Expo modules, and no other notification library is involved.
 */
import type { DevicePushToken, KeyValueStorage, NotificationsAdapter, OsPermission, PlatformAdapter } from "@krontelli/sdk-react-native";
import { AppState, NativeEventEmitter, NativeModules, PermissionsAndroid, Platform } from "react-native";

declare const __DEV__: boolean | undefined;

export interface BarePlatformOptions {
  /** Defaults to the version in the app's own native project. */
  appVersion?: string;
  /** Android: the channel a push lands on, created at startup. Name it in the manifest's default_notification_channel_id too. */
  androidChannel?: { id: string; name: string };
}

interface NativeModule {
  getConstants?(): { appVersion?: string };
  getPermission(): Promise<OsPermission>;
  requestPermission?(): Promise<OsPermission>;
  noteAsked?(): void;
  getDevicePushToken(): Promise<string>;
  getLastNotificationResponse(): Promise<Record<string, unknown> | null>;
  createChannel(id: string, name: string): void;
  secureGet(key: string): Promise<string | null>;
  secureSet(key: string, value: string): Promise<void>;
  secureRemove(key: string): Promise<void>;
  plainGet(key: string): Promise<string | null>;
  plainSet(key: string, value: string): Promise<void>;
  plainRemove(key: string): Promise<void>;
}

function storage(get: NativeModule["plainGet"], set: NativeModule["plainSet"], remove: NativeModule["plainRemove"]): KeyValueStorage {
  return { getItem: (k) => get(k), setItem: (k, v) => set(k, v), removeItem: (k) => remove(k) };
}

function createNotifications(native: NativeModule): NotificationsAdapter {
  const emitter = new NativeEventEmitter(NativeModules.KrontelliBare);
  const type = Platform.OS === "ios" ? "ios" : "android";
  const toToken = (data: string): DevicePushToken => ({ type, data });
  // What the SDK reads as a notification: a plain data map, wrapped the way a tap is.
  const on = (event: string, map: (data: unknown) => unknown, listener: (value: never) => void) => {
    const sub = emitter.addListener(event, (body: unknown) => (listener as (v: unknown) => void)(map((body as { data?: unknown })?.data)));
    return () => sub.remove();
  };
  return {
    getPermission: () => native.getPermission(),
    async requestPermission() {
      if (Platform.OS === "ios") return native.requestPermission!();
      if (Number(Platform.Version) >= 33) {
        await PermissionsAndroid.request("android.permission.POST_NOTIFICATIONS");
        native.noteAsked?.();
      }
      return native.getPermission();
    },
    getDevicePushToken: async () => toToken(await native.getDevicePushToken()),
    addPushTokenListener(listener) {
      const sub = emitter.addListener("KrontelliToken", (body: unknown) => listener(toToken((body as { token: string }).token)));
      return () => sub.remove();
    },
    addNotificationReceivedListener: (listener) => on("KrontelliReceived", (data) => data, listener as (value: never) => void),
    addNotificationResponseReceivedListener: (listener) => on("KrontelliOpened", (data) => ({ notification: data }), listener as (value: never) => void),
    async getLastNotificationResponse() {
      const data = await native.getLastNotificationResponse();
      return data ? { notification: data } : null;
    },
  };
}

export function createBarePlatform(options: BarePlatformOptions = {}): PlatformAdapter {
  const native = NativeModules.KrontelliBare as NativeModule | undefined;
  if (!native) throw new Error("@krontelli/sdk-react-native-bare: the native module is missing; rebuild the app");
  if (Platform.OS === "android" && options.androidChannel) native.createChannel(options.androidChannel.id, options.androidChannel.name);

  const appVersion = options.appVersion ?? native.getConstants?.().appVersion;
  const deviceInfo = (): ReturnType<PlatformAdapter["deviceInfo"]> => {
    const info: ReturnType<PlatformAdapter["deviceInfo"]> = { os_version: String(Platform.Version) };
    if (appVersion) info.app_version = appVersion;
    try {
      const resolved = Intl.DateTimeFormat().resolvedOptions();
      if (resolved.timeZone) info.timezone = resolved.timeZone;
      if (resolved.locale && resolved.locale !== "und") info.locale = resolved.locale;
    } catch {
      /* the SDK sends what it has */
    }
    return info;
  };

  const g = globalThis as { crypto?: { getRandomValues?: (a: Uint8Array) => Uint8Array; randomUUID?: () => string } };
  const randomUUID = () => {
    if (g.crypto?.randomUUID) return g.crypto.randomUUID();
    const h = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16));
    h[12] = "4";
    h[16] = ((parseInt(h[16] as string, 16) & 0x3) | 0x8).toString(16);
    const s = h.join("");
    return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20)}`;
  };

  return {
    platform: Platform.OS === "ios" ? "ios" : "android",
    isDev: typeof __DEV__ === "boolean" ? __DEV__ : false,
    secureStorage: storage((k) => native.secureGet(k), (k, v) => native.secureSet(k, v), (k) => native.secureRemove(k)),
    storage: storage((k) => native.plainGet(k), (k, v) => native.plainSet(k, v), (k) => native.plainRemove(k)),
    fetch: (...args) => fetch(...args),
    randomUUID,
    now: () => Date.now(),
    deviceInfo,
    appState: {
      current: () => (AppState.currentState as ReturnType<PlatformAdapter["appState"]["current"]>) ?? "unknown",
      subscribe(listener) {
        const sub = AppState.addEventListener("change", listener);
        return () => sub.remove();
      },
    },
    notifications: createNotifications(native),
    // A release build is signed for production APNs, a debug build for the sandbox; the SDK falls back to that.
    apnsEnvironmentHint: () => null,
  };
}
