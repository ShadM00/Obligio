package com.krontelli.bare

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.app.NotificationManagerCompat
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.BaseActivityEventListener
import com.facebook.react.bridge.LifecycleEventListener
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.google.firebase.messaging.FirebaseMessaging
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class KrontelliBareModule(private val context: ReactApplicationContext) : ReactContextBaseJavaModule(context), LifecycleEventListener {
  private val plain = context.getSharedPreferences("krontelli.bare", Context.MODE_PRIVATE)
  private val sealed = context.getSharedPreferences("krontelli.bare.sealed", Context.MODE_PRIVATE)

  /** A tap that reached the Activity before JavaScript listened. Delivered once. */
  private var pendingOpened: Map<String, String>? = null
  private var launchIntentRead = false

  private val activityListener = object : BaseActivityEventListener() {
    override fun onNewIntent(intent: Intent) {
      val data = openedData(intent) ?: return
      intent.removeExtra("kt")
      if (listeners > 0) emit("KrontelliOpened", dataEvent(data)) else pendingOpened = data
    }
  }

  private var listeners = 0

  init {
    active = this
    context.addActivityEventListener(activityListener)
    context.addLifecycleEventListener(this)
  }

  override fun getName() = "KrontelliBare"

  override fun getConstants(): Map<String, Any> {
    val version = context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
    return mapOf("appVersion" to version)
  }

  override fun invalidate() {
    context.removeActivityEventListener(activityListener)
    context.removeLifecycleEventListener(this)
    if (active === this) active = null
    super.invalidate()
  }

  override fun onHostResume() {
    inForeground = true
  }

  override fun onHostPause() {
    inForeground = false
  }

  override fun onHostDestroy() {
    inForeground = false
  }

  // Required by NativeEventEmitter.
  @ReactMethod
  fun addListener(eventName: String) {
    listeners++
  }

  @ReactMethod
  fun removeListeners(count: Int) {
    listeners = (listeners - count).coerceAtLeast(0)
  }

  private fun emit(name: String, body: WritableMap) {
    if (context.hasActiveReactInstance()) {
      context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(name, body)
    }
  }

  private fun dataEvent(data: Map<String, String>): WritableMap {
    val map = Arguments.createMap()
    data.forEach { (key, value) -> map.putString(key, value) }
    return Arguments.createMap().apply { putMap("data", map) }
  }

  private fun openedData(intent: Intent?): Map<String, String>? {
    val extras = intent?.extras ?: return null
    // A tap carries the message's data; only ours has the delivery block.
    if (extras.getString("kt") == null) return null
    val data = HashMap<String, String>()
    for (key in extras.keySet()) {
      if (key.startsWith("google.") || key == "from" || key == "collapse_key" || key.startsWith("gcm.")) continue
      extras.getString(key)?.let { data[key] = it }
    }
    return data
  }

  @ReactMethod
  fun getPermission(promise: Promise) {
    val enabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
    if (enabled) {
      promise.resolve("granted")
    } else {
      // Before Android 13 there is no prompt, so "off" can only be the person's own choice.
      val asked = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || plain.getBoolean("krontelli.bare.asked", false)
      promise.resolve(if (asked) "denied" else "undetermined")
    }
  }

  /** The prompt itself goes through PermissionsAndroid in JavaScript; this remembers that it was shown. */
  @ReactMethod
  fun noteAsked() {
    plain.edit().putBoolean("krontelli.bare.asked", true).apply()
  }

  @ReactMethod
  fun getDevicePushToken(promise: Promise) {
    FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
      if (task.isSuccessful && task.result != null) promise.resolve(task.result)
      else promise.reject("token", task.exception?.message ?: "no token", task.exception)
    }
  }

  @ReactMethod
  fun getLastNotificationResponse(promise: Promise) {
    pendingOpened?.let {
      pendingOpened = null
      promise.resolve(dataEvent(it).getMap("data"))
      return
    }
    if (!launchIntentRead) {
      launchIntentRead = true
      val intent = context.currentActivity?.intent
      val data = openedData(intent)
      if (data != null) {
        intent?.removeExtra("kt")
        promise.resolve(dataEvent(data).getMap("data"))
        return
      }
    }
    promise.resolve(null)
  }

  @ReactMethod
  fun createChannel(id: String, name: String) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    manager.createNotificationChannel(NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH))
  }

  private fun key(): SecretKey {
    val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(
      KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .build(),
    )
    return generator.generateKey()
  }

  @ReactMethod
  fun secureGet(name: String, promise: Promise) {
    val stored = sealed.getString(name, null)
    if (stored == null) {
      promise.resolve(null)
      return
    }
    try {
      val bytes = Base64.decode(stored, Base64.NO_WRAP)
      val cipher = Cipher.getInstance(TRANSFORMATION)
      cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes, 0, IV_BYTES))
      promise.resolve(String(cipher.doFinal(bytes, IV_BYTES, bytes.size - IV_BYTES), Charsets.UTF_8))
    } catch (e: Exception) {
      // The key did not survive (restore to a new device). Nothing to read; the SDK registers again.
      sealed.edit().remove(name).apply()
      promise.resolve(null)
    }
  }

  @ReactMethod
  fun secureSet(name: String, value: String, promise: Promise) {
    try {
      val cipher = Cipher.getInstance(TRANSFORMATION)
      cipher.init(Cipher.ENCRYPT_MODE, key())
      val out = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
      sealed.edit().putString(name, Base64.encodeToString(out, Base64.NO_WRAP)).apply()
      promise.resolve(null)
    } catch (e: Exception) {
      promise.reject("keystore", e.message, e)
    }
  }

  @ReactMethod
  fun secureRemove(name: String, promise: Promise) {
    sealed.edit().remove(name).apply()
    promise.resolve(null)
  }

  @ReactMethod
  fun plainGet(name: String, promise: Promise) {
    promise.resolve(plain.getString(name, null))
  }

  @ReactMethod
  fun plainSet(name: String, value: String, promise: Promise) {
    plain.edit().putString(name, value).apply()
    promise.resolve(null)
  }

  @ReactMethod
  fun plainRemove(name: String, promise: Promise) {
    plain.edit().remove(name).apply()
    promise.resolve(null)
  }

  companion object {
    private const val KEY_ALIAS = "krontelli.bare.key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_BYTES = 12

    @Volatile private var active: KrontelliBareModule? = null
    @Volatile private var inForeground = false

    fun onToken(token: String) {
      active?.let { module -> module.emit("KrontelliToken", Arguments.createMap().apply { putString("token", token) }) }
    }

    fun onReceived(data: Map<String, String>) {
      val module = active ?: return
      if (inForeground) module.emit("KrontelliReceived", module.dataEvent(data))
    }
  }
}
