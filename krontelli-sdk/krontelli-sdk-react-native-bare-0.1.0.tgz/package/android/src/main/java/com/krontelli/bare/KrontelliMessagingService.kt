package com.krontelli.bare

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Android shows a notification message by itself while the app is in the background, and hands it
 * here only while the app is in front. So this shows it in that one case, carrying the same extras
 * a system-shown one would, which makes a tap look the same either way.
 */
class KrontelliMessagingService : FirebaseMessagingService() {
  override fun onNewToken(token: String) {
    KrontelliBareModule.onToken(token)
  }

  override fun onMessageReceived(message: RemoteMessage) {
    message.notification?.let { show(message, it) }
    KrontelliBareModule.onReceived(message.data)
  }

  private fun show(message: RemoteMessage, notification: RemoteMessage.Notification) {
    val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return
    val extras = Bundle()
    message.data.forEach { (key, value) -> extras.putString(key, value) }
    launch.putExtras(extras)
    val id = message.messageId?.hashCode() ?: System.currentTimeMillis().toInt()
    val tap = PendingIntent.getActivity(this, id, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val channel = notification.channelId ?: defaultChannel(this) ?: NotificationCompat.CATEGORY_MESSAGE
    val builder = NotificationCompat.Builder(this, channel)
      .setContentTitle(notification.title)
      .setContentText(notification.body)
      .setSmallIcon(smallIcon(this))
      .setAutoCancel(true)
      .setContentIntent(tap)
    if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, builder.build())
    }
  }

  companion object {
    private fun metaData(context: Context): Bundle? =
      context.packageManager.getApplicationInfo(context.packageName, PackageManager.GET_META_DATA).metaData

    fun defaultChannel(context: Context): String? =
      metaData(context)?.getString("com.google.firebase.messaging.default_notification_channel_id")

    private fun smallIcon(context: Context): Int {
      val icon = metaData(context)?.getInt("com.google.firebase.messaging.default_notification_icon") ?: 0
      return if (icon != 0) icon else context.applicationInfo.icon
    }
  }
}
