# @krontelli/sdk-react-native-bare

Lets `@krontelli/sdk-react-native` run in a React Native app without Expo. Used by Kinship Guard and Obligio.
Expo apps do not install it.

Provides `createBarePlatform()`, passed as `platform` to `Krontelli.init`, backed by a small native module: the APNs
token, FCM token, permission, notification taps, Keychain / Android Keystore storage. The app needs `google-services.json`.

## Set up

```sh
npm install ./vendor/krontelli-sdk-react-native-<v>.tgz ./vendor/krontelli-sdk-react-native-bare-<v>.tgz
cd ios && bundle exec pod install && cd ..
bundle exec ruby node_modules/@krontelli/sdk-react-native-bare/scripts/add-nse.rb \
  --project ios/App.xcodeproj --app-target App --sdk node_modules/@krontelli/sdk-react-native
```

AppDelegate.swift:

```swift
import KrontelliBare
// first line of didFinishLaunchingWithOptions, before React Native starts:
KrontelliBarePush.shared.start()

func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
  KrontelliBarePush.shared.didRegister(deviceToken: deviceToken)
}
func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
  KrontelliBarePush.shared.didFailToRegister(error: error)
}
```

AndroidManifest.xml, inside `<application>`, naming the channel and a monochrome icon:

```xml
<meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="reminders" />
<meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_notification" />
```

Then:

```ts
import Krontelli from "@krontelli/sdk-react-native";
import { createBarePlatform } from "@krontelli/sdk-react-native-bare";

Krontelli.init({
  apiBaseUrl: "https://api.krontelli.com",
  publicKey,
  requestPermissionOnInit: false,
  platform: createBarePlatform({ appVersion, androidChannel: { id: "reminders", name: "Reminders" } }),
});
```

Autolinking finds the native module. The `aps-environment` entitlement must exist in the app target, and the App ID
`<bundle id>.KrontelliNSE` needs a provisioning profile if the project signs manually.
