/**
 * @krontelli/sdk-react-native config plugin.
 *
 * iOS:  adds a Notification Service Extension target ("KrontelliNSE") that records `received`
 *       receipts and attaches rich media (see ./withKrontelliNSE.js), and enables the push
 *       entitlement + remote-notification background mode on the main app.
 * Android: declares the default notification channel(s) and the FCM default-channel meta-data
 *       (see ./withKrontelliAndroid.js). Firebase (google-services.json) itself is configured by the
 *       app with the usual `googleServicesFile` setting; this plugin does not touch it.
 *
 * Props:
 *   apiBaseUrl        required  e.g. "https://api.krontelli.com" (compiled into the extension)
 *   iosDeploymentTarget optional  default "15.1"
 *   nseBundleIdSuffix optional  default "KrontelliNSE" → <app bundle id>.KrontelliNSE
 *   androidChannels   optional  [{ id, name, importance?, description?, sound?, vibrate? }]
 *                               default: one "default" channel named "Notifications"
 *   androidDefaultChannelId optional  default "default"
 *   androidIcon       optional  resource name for the small notification icon (e.g. "notification_icon")
 *   androidColor      optional  "#RRGGBB" accent colour
 */
const { withKrontelliIOS } = require("./withKrontelliNSE");
const { withKrontelliAndroid } = require("./withKrontelliAndroid");

let createRunOncePlugin;
try {
  ({ createRunOncePlugin } = require("expo/config-plugins"));
} catch {
  ({ createRunOncePlugin } = require("@expo/config-plugins"));
}

const pkg = require("../package.json");

function validateProps(props) {
  if (!props || typeof props.apiBaseUrl !== "string" || !/^https?:\/\//.test(props.apiBaseUrl)) {
    throw new Error('[@krontelli/sdk-react-native] plugin prop "apiBaseUrl" (https://…) is required');
  }
  return {
    apiBaseUrl: props.apiBaseUrl.replace(/\/+$/, ""),
    iosDeploymentTarget: props.iosDeploymentTarget || "15.1",
    nseBundleIdSuffix: props.nseBundleIdSuffix || "KrontelliNSE",
    androidChannels: props.androidChannels,
    androidDefaultChannelId: props.androidDefaultChannelId || "default",
    androidIcon: props.androidIcon,
    androidColor: props.androidColor,
  };
}

const withKrontelli = (config, rawProps) => {
  const props = validateProps(rawProps);
  config = withKrontelliIOS(config, props);
  config = withKrontelliAndroid(config, props);
  return config;
};

module.exports = createRunOncePlugin(withKrontelli, pkg.name, pkg.version);
