/**
 * iOS side of the plugin.
 *
 *  A. Main app: `aps-environment` entitlement + `remote-notification` background mode.
 *  B. Notification Service Extension target "KrontelliNSE" added to the Xcode project:
 *       - copies ./nse/NotificationService.swift and ./nse/Info.plist into ios/KrontelliNSE/,
 *         substituting the API base URL and the app's version/build number;
 *       - adds a PBXNativeTarget (product type app-extension) with Sources + Resources +
 *         Frameworks build phases, Debug/Release build configurations and an "Embed App
 *         Extensions" copy-files phase on the main app target;
 *       - sets the bundle id to <app bundle id>.<nseBundleIdSuffix> and inherits the main target's
 *         DEVELOPMENT_TEAM / CODE_SIGN_STYLE so automatic signing works on EAS.
 *
 * This follows the pattern used by onesignal-expo-plugin and expo-notification-service-extension-plugin
 * (`mods.ios.xcodeproj` + the `xcode` package API that @expo/config-plugins exposes). The parts
 * marked "verify on a real build" are the ones that depend on Xcode / EAS behaviour we cannot
 * exercise in unit tests:
 *   - EAS credentials: the extension needs its own provisioning profile. With EAS Build the
 *     target is picked up automatically when it appears in the project; add
 *     `"ios": { "appExtensions": [...] }` to eas.json (see README) if you manage credentials
 *     manually.
 *   - `expo prebuild --clean` is required after changing plugin props (the target is only
 *     created when absent).
 */
const fs = require("fs");
const path = require("path");

let plugins;
try {
  plugins = require("expo/config-plugins");
} catch {
  plugins = require("@expo/config-plugins");
}
const { withEntitlementsPlist, withInfoPlist, withXcodeProject, withDangerousMod, IOSConfig } = plugins;

const NSE_NAME = "KrontelliNSE";
const NSE_FILES = ["NotificationService.swift", "Info.plist"];

/** A. Push entitlement + background mode on the main app. */
function withMainAppPushCapability(config) {
  config = withEntitlementsPlist(config, (cfg) => {
    // The signed value is ultimately decided by the provisioning profile; declaring
    // "development" here is what EAS/Xcode expect for the source entitlements file.
    if (!cfg.modResults["aps-environment"]) cfg.modResults["aps-environment"] = "development";
    return cfg;
  });
  config = withInfoPlist(config, (cfg) => {
    const modes = new Set(cfg.modResults.UIBackgroundModes || []);
    modes.add("remote-notification");
    cfg.modResults.UIBackgroundModes = Array.from(modes);
    return cfg;
  });
  return config;
}

/** B1. Copy the extension sources into ios/KrontelliNSE with substitutions. */
function withNSESources(config, props) {
  return withDangerousMod(config, [
    "ios",
    async (cfg) => {
      const iosRoot = cfg.modRequest.platformProjectRoot;
      const dest = path.join(iosRoot, NSE_NAME);
      fs.mkdirSync(dest, { recursive: true });
      const appVersion = cfg.version || "1.0.0";
      const buildNumber = (cfg.ios && cfg.ios.buildNumber) || "1";
      for (const file of NSE_FILES) {
        let src = fs.readFileSync(path.join(__dirname, "nse", file), "utf8");
        src = src
          .replace(/__KRONTELLI_API_BASE_URL__/g, props.apiBaseUrl)
          .replace(/__KRONTELLI_APP_VERSION__/g, appVersion)
          .replace(/__KRONTELLI_BUILD_NUMBER__/g, String(buildNumber));
        fs.writeFileSync(path.join(dest, file), src);
      }
      return cfg;
    },
  ]);
}

/** B2. Add the PBXNativeTarget. */
function withNSETarget(config, props) {
  return withXcodeProject(config, (cfg) => {
    const project = cfg.modResults;
    const appBundleId = cfg.ios && cfg.ios.bundleIdentifier;
    if (!appBundleId) throw new Error("[@krontelli/sdk-react-native] ios.bundleIdentifier must be set in the Expo config");
    const nseBundleId = `${appBundleId}.${props.nseBundleIdSuffix}`;

    // Idempotency: re-running prebuild without --clean must not add a second target.
    const existing = Object.values(project.hash.project.objects.PBXNativeTarget || {}).find((t) => t && t.name === `"${NSE_NAME}"`);
    if (existing) return cfg;

    // The `xcode` package needs these groups to exist before addTarget() (well-known quirk).
    const objects = project.hash.project.objects;
    objects.PBXTargetDependency = objects.PBXTargetDependency || {};
    objects.PBXContainerItemProxy = objects.PBXContainerItemProxy || {};

    // 1. Group with the extension's files.
    const group = project.addPbxGroup(NSE_FILES, NSE_NAME, NSE_NAME);
    // Attach it to the main group so it shows up in the navigator.
    const mainGroupKey = project.getFirstProject().firstProject.mainGroup;
    project.addToPbxGroup(group.uuid, mainGroupKey);

    // 2. Target.
    const target = project.addTarget(NSE_NAME, "app_extension", NSE_NAME, nseBundleId);

    // 3. Build phases: sources, resources, frameworks.
    project.addBuildPhase(["NotificationService.swift"], "PBXSourcesBuildPhase", "Sources", target.uuid);
    project.addBuildPhase([], "PBXResourcesBuildPhase", "Resources", target.uuid);
    project.addBuildPhase([], "PBXFrameworksBuildPhase", "Frameworks", target.uuid);
    // addTarget() already adds the "Embed App Extensions" copy-files phase on the first (app)
    // target and a target dependency. Verify on a real build that the product appears under
    // Build Phases → Embed Foundation Extensions of the app target.

    // 4. Build settings: inherit signing from the main target, Swift 5, no code-coverage noise.
    const mainTarget = IOSConfig.Target.findFirstNativeTarget
      ? IOSConfig.Target.findFirstNativeTarget(project)
      : project.getFirstTarget().firstTarget;
    const mainSettings = firstBuildSettings(project, mainTarget);
    const configurations = project.pbxXCBuildConfigurationSection();
    for (const key of Object.keys(configurations)) {
      const conf = configurations[key];
      if (!conf || typeof conf !== "object" || !conf.buildSettings) continue;
      if (unquote(conf.buildSettings.PRODUCT_NAME) !== NSE_NAME) continue;
      const bs = conf.buildSettings;
      bs.PRODUCT_BUNDLE_IDENTIFIER = `"${nseBundleId}"`;
      bs.INFOPLIST_FILE = `"${NSE_NAME}/Info.plist"`;
      bs.IPHONEOS_DEPLOYMENT_TARGET = props.iosDeploymentTarget;
      bs.SWIFT_VERSION = "5.0";
      bs.TARGETED_DEVICE_FAMILY = '"1,2"';
      bs.CODE_SIGN_STYLE = mainSettings.CODE_SIGN_STYLE || "Automatic";
      if (mainSettings.DEVELOPMENT_TEAM) bs.DEVELOPMENT_TEAM = mainSettings.DEVELOPMENT_TEAM;
      bs.MARKETING_VERSION = `"${cfg.version || "1.0.0"}"`;
      bs.CURRENT_PROJECT_VERSION = `"${(cfg.ios && cfg.ios.buildNumber) || "1"}"`;
      bs.GENERATE_INFOPLIST_FILE = "NO";
      bs.SKIP_INSTALL = "YES";
      bs.CLANG_ENABLE_MODULES = "YES";
      bs.SWIFT_OPTIMIZATION_LEVEL = conf.name === "Debug" ? '"-Onone"' : '"-O"';
      bs.DEBUG_INFORMATION_FORMAT = conf.name === "Debug" ? "dwarf" : '"dwarf-with-dsym"';
    }
    return cfg;
  });
}

function firstBuildSettings(project, target) {
  try {
    const listKey = (target && target.buildConfigurationList) || project.getFirstTarget().firstTarget.buildConfigurationList;
    const list = project.pbxXCConfigurationList()[listKey];
    const confs = project.pbxXCBuildConfigurationSection();
    for (const ref of list.buildConfigurations || []) {
      const conf = confs[ref.value];
      if (conf && conf.buildSettings) return conf.buildSettings;
    }
  } catch {
    /* fall through */
  }
  return {};
}

function unquote(v) {
  return typeof v === "string" ? v.replace(/^"|"$/g, "") : v;
}

// Note: a Notification Service Extension needs no entitlements of its own (no aps-environment,
// no Keychain group): the receipt token in the payload is its only credential.

function withKrontelliIOS(config, props) {
  config = withMainAppPushCapability(config);
  config = withNSESources(config, props);
  config = withNSETarget(config, props);
  return config;
}

module.exports = { withKrontelliIOS, NSE_NAME };
