# @krontelli/sdk-react-native

Push notifications and product analytics for React Native / Expo apps, talking only to your own
Krontelli API. One package, five internal modules: **core** (installation identity), **push**,
**events**, **identity** and an optional **diagnostics bridge** to Sentry / GlitchTip.

The wire contract is `packages/shared/openapi.json` (the `sdk` tag). Native APNs / FCM tokens are
used directly — nothing goes through Expo's push service.

## Install

```sh
npx expo install @krontelli/sdk-react-native expo-notifications expo-secure-store @react-native-async-storage/async-storage expo-device
# optional but recommended: better version / locale detection and a real UUID source
npx expo install expo-application expo-constants expo-crypto expo-localization
```

Peer dependencies: `react-native`, `expo`, `expo-notifications`, `expo-secure-store`,
`@react-native-async-storage/async-storage`; `expo-device` is optional. The SDK has no runtime
dependencies of its own.

Add the config plugin (needed for iOS receipts / rich media and Android channels) and rebuild:

```jsonc
// app.json
{
  "expo": {
    "ios": { "bundleIdentifier": "com.example.app" },
    "android": { "package": "com.example.app", "googleServicesFile": "./google-services.json" },
    "plugins": [
      "expo-notifications",
      ["@krontelli/sdk-react-native", { "apiBaseUrl": "https://api.krontelli.com" }]
    ]
  }
}
```

```sh
npx expo prebuild --clean
eas build --profile development --platform all
```

The SDK needs a development build; it does not run in Expo Go (native push tokens are unavailable there).

## Init

```ts
import Krontelli from "@krontelli/sdk-react-native";

Krontelli.init({
  apiBaseUrl: "https://api.krontelli.com",
  publicKey: "kt_pub_…",         // the app's public key: it can only create installations
  appVersion: "1.4.2",           // optional; read from expo-application otherwise
  // apnsEnvironment: "production", // optional override, see "APNs environment"
  // requestPermissionOnInit: false, // ask the OS yourself at the right moment instead
  // sentry: Sentry,                 // optional @sentry/react-native module (GlitchTip-compatible)
});
```

Call `init()` once, as early as possible (module scope of your root file is fine). Every other
function can be called before `init()` resolves: `track()` / `screen()` / `onNotificationOpened()`
are buffered and replayed, the async ones wait for the client to be ready.

On first launch the SDK `POST /v1/installations` with the public key, receives the installation
credential **once** and stores it in `expo-secure-store` (Keychain / Keystore). If secure storage is
unavailable it falls back to AsyncStorage and logs a warning. Every launch it `PATCH`es
`os_version`, `app_version`, `sdk_version`, `timezone` (from `Intl`) and `locale`, and rotates the
credential when it is older than `credentialRotationDays` (default 30; the old secret stays valid
for 10 minutes so the swap is safe).

### Public API

| Function | Does |
| --- | --- |
| `init(options)` | Registers / restores the installation, starts the event schedule and push listeners. |
| `track(name, props?)` | Queues a custom event. Synchronous. |
| `screen(name, props?)` | Queues `screen_view` with `{ screen: name }`. |
| `login(identityToken)` | Links this installation to a person (see below). Resolves `{ person_id, external_id }`. |
| `logout()` | Unlinks immediately; marketing consent reverts to anonymous `false`. |
| `requestPermission()` | Asks the OS for notification permission, reports it and the token. Returns `granted \| denied \| provisional \| undetermined`. The SDK also re-reads the permission (without prompting) every time the app returns to the foreground, so a change made in system Settings reaches the server on its own. |
| `setPushOptIn(bool)` | In-app marketing push opt-in (separate from the OS permission). |
| `setMarketingConsent(bool)` | Marketing consent; written to the person if linked, else to the installation. |
| `onNotificationOpened(cb)` | `cb({ deliveryId, deepLink, imageUrl, data, raw })` on every tap, including the one that cold-started the app. Returns an unsubscribe function. |
| `getInstallationId()` | The installation id, or `null` until registration completes. |
| `flush()` | Sends every queued event now. |
| `rotateCredential()` | Forces a credential rotation. |

All functions are also available as named exports.

```ts
import { onNotificationOpened, requestPermission, screen } from "@krontelli/sdk-react-native";

onNotificationOpened(({ deepLink }) => {
  if (deepLink) Linking.openURL(deepLink); // or router.push(...)
});

// after onboarding, where the value of notifications is obvious to the user:
await requestPermission();

// on navigation state change:
screen("Checkout", { step: 2 });
```

## Identity-token flow (login)

The SDK never sees user credentials. After **your backend** has authenticated the user it mints a
short-lived identity token; the app passes it to `Krontelli.login()`, which forwards it verbatim to
`POST /v1/installations/me/login`.

Token requirements (verified server side):

- JWT, `alg: HS256`, with a `kid` header naming one of the app's identity signing secrets
  (two can be active during rotation; a retiring secret is accepted for 24 h)
- `sub` = your external user id (what Krontelli calls `external_id`)
- `aud` = the Krontelli app id
- `iat` and `exp`, with `exp - iat ≤ 300` seconds
- `jti` unique per token: tokens are single use

```ts
// backend (Node, jose)
import { SignJWT } from "jose";
const token = await new SignJWT({})
  .setProtectedHeader({ alg: "HS256", kid: process.env.KT_IDENTITY_KID! })
  .setSubject(user.id)
  .setAudience(process.env.KT_APP_ID!)
  .setIssuedAt()
  .setExpirationTime("5m")
  .setJti(crypto.randomUUID())
  .sign(new TextEncoder().encode(process.env.KT_IDENTITY_SECRET!));
```

```ts
// app
const { identityToken } = await api.post("/session"); // your own login endpoint returns it
await Krontelli.login(identityToken);
// ...
await Krontelli.logout();
```

`login()` rejects with a `KrontelliError` (`status`, `code`, `message`) when the token is invalid or
expired; mint a fresh one and retry. Logging in as a different user on the same device closes the
previous link and resets the installation's anonymous consent.

### Re-enrolment rule

A `401` on any call other than `login` means the server no longer recognises the installation
(revoked from the dashboard or the server API). The SDK clears the stored credential, registers a
**new** installation, retries the call once, resends the push subscription and forgets the person
link. The app's next `login()` re-links the user. A `401` from `login` itself is returned to the app
(bad identity token) and does not re-enrol.

## Events

Automatic events: `first_open`, `app_open`, `session_start` (cold start and after > 30 s in the
background), `screen_view` (via `screen()`), `app_update` (`{ from, to }` when the app version
changes), `push_received` (foreground arrivals) and `push_opened` (`{ delivery_id, deep_link }`).

**Consent before anything is sent.** `init({ …, consentRequired: true })` is the equivalent of OneSignal's
`setConsentRequired(true)`: until the app calls `Krontelli.setConsentGiven(true)` the SDK does not register
the device, drops `track()`/`screen()` calls, reports no push token and rejects `login()`; `setPushOptIn()`
is only stored, and `requestPermission()` only shows the OS dialog. The answer is stored, so later launches
start normally. `setConsentGiven(false)` reports `push_opt_in = false` (so sends stop), drops queued events
and stops the SDK.

**Push-only apps.** `init({ …, events: { automatic: false } })` turns every automatic event off, so the
SDK sends nothing to `/v1/events` unless the app calls `track()` or `screen()`. Registration, the push
subscription and delivery receipts are unchanged, so message stats still work. Use it for an app whose
privacy promise doesn't cover usage analytics: `session_start` carries how long the app was in the
background, which in a sleep or health app says something about the person.

Delivery guarantees:

- events are persisted to AsyncStorage immediately and survive restarts;
- batches of ≤ 100 events / ≤ 256 KB are sent every 10 s, when 20 events are waiting, on
  `flush()` and when the app goes to the background; one event is ≤ 32 KB;
- `event_id` is a UUID v4 minted on device and the server is idempotent on it, so retries are safe;
- `503` + `Retry-After` keeps the batch queued and backs off; other failures back off
  exponentially with jitter (1 s → 5 min);
- **7-day drop rule**: an event older than 7 days is dropped instead of sent, so the server's 14-day
  dedup window always covers a retried id;
- `client_ts` is informational; the server's `received_at` orders events.

## Receipts

Each push carries a `kt` block, `{ d: <delivery_id>, r: <receipt_token> }`: at the APNs payload root
on iOS, and as a JSON string under `data.kt` on Android. The receipt token is an HMAC for that one
delivery, so a receipt call needs no installation credential, no Keychain access and cannot be
abused for anything else.

| Receipt | iOS | Android |
| --- | --- | --- |
| `received` (background) | **KrontelliNSE** extension, installed by the config plugin; also downloads `image_url` for rich media. Budget 20 s. | Not available: FCM notification messages are displayed by the system without waking the app. Coverage % in the dashboard accounts for this. |
| `received` (foreground) | SDK, from expo-notifications' received listener | same |
| `opened` | SDK, from the response listener (foreground, background and cold start) | same |

Receipts are idempotent; the NSE and the foreground listener may both post `received` for one delivery.

Foreground display is up to the app, through expo-notifications:

```ts
import * as Notifications from "expo-notifications";
Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: true, shouldSetBadge: false }),
});
```

## APNs environment

The SDK reports `environment: "sandbox" | "production"` with every APNs token. The signed
`aps-environment` entitlement is decided by the provisioning profile and is not readable from JS, so
the SDK uses, in order:

1. `init({ apnsEnvironment })` — explicit override;
2. `ios.entitlements["aps-environment"]` from the Expo config when you set it
   (`development` → sandbox, `production` → production);
3. `__DEV__ ? "sandbox" : "production"`.

Rule 3 is right for development builds (sandbox) and TestFlight / App Store / ad-hoc builds
(production). Use the override for a release-configuration build signed with a development profile.
Verify on a real device: a token reported to the wrong environment is rejected by Apple with
`BadDeviceToken` and the subscription is marked invalid.

## Config plugin

```jsonc
["@krontelli/sdk-react-native", {
  "apiBaseUrl": "https://api.krontelli.com",      // required; compiled into the NSE
  "iosDeploymentTarget": "15.1",                   // optional
  "nseBundleIdSuffix": "KrontelliNSE",             // optional → com.example.app.KrontelliNSE
  "androidDefaultChannelId": "default",            // optional
  "androidChannels": [                             // optional, default: one "default" channel
    { "id": "default", "name": "Notifications", "importance": "high" },
    { "id": "promotions", "name": "Offers", "importance": "default", "sound": false }
  ],
  "androidIcon": "notification_icon",              // optional drawable name
  "androidColor": "#FF6600"                        // optional accent colour
}]
```

iOS: adds the `aps-environment` entitlement and `remote-notification` background mode to the app,
and a Notification Service Extension target **KrontelliNSE** (Swift, `ios/KrontelliNSE/`) that posts
`received` receipts and attaches `image_url`. The target inherits the app's `DEVELOPMENT_TEAM` /
`CODE_SIGN_STYLE`; EAS Build provisions it automatically. If you manage credentials yourself, list it
in `eas.json`:

```jsonc
"ios": { "appExtensions": [{ "targetName": "KrontelliNSE", "bundleIdentifier": "com.example.app.KrontelliNSE" }] }
```

Android: writes `com.google.firebase.messaging.default_notification_channel_id` (and icon / colour
when given) to the manifest and creates the channel(s) in `MainApplication.onCreate()` so a
background notification message lands on the right channel before the JS runtime has run. Firebase
itself is configured by your `googleServicesFile`. Re-run `npx expo prebuild --clean` after changing
plugin props.

## Diagnostics bridge

Pass your Sentry-compatible module and the SDK tags errors with the installation and person:

```ts
import * as Sentry from "@sentry/react-native";
Krontelli.init({ ..., sentry: Sentry });
// → Sentry.setUser({ id: installationId, krontelli_installation_id, krontelli_person_id?, username: external_id? })
```

No import of Sentry anywhere in the SDK; anything with a `setUser()` works (GlitchTip included).

## Migrating from OneSignal

- **One Notification Service Extension.** iOS runs exactly one NSE per app. Remove
  `onesignal-expo-plugin` (or disable its `OneSignalNotificationServiceExtension`) before adding
  this plugin, then `expo prebuild --clean`. Two extensions means one never runs.
- **iOS notification delegate.** Only one object can be the `UNUserNotificationCenter` delegate, and
  the SDK hears taps through expo-notifications. OneSignal and `@react-native-firebase/messaging` both
  install their own delegate at launch; expo-notifications then logs "encountered already present
  delegate" and never sees a tap, so there is no `opened` receipt and no deep link. Fix (proven on the
  Kingdom Bible Quiz pilot): remove `@react-native-firebase/messaging` if the app doesn't use it, and in
  `AppDelegate` after `super.application(...didFinishLaunchingWithOptions:)` set
  `UNUserNotificationCenter.current().delegate = NotificationCenterManager.shared` (`import EXNotifications`).
  OneSignal swizzles `setDelegate:` and wraps the new delegate, so its own pushes keep working. Check the
  launch log for the expo-notifications warning on every dual-SDK build.
- **Dual-SDK extension.** With committed native folders the config plugin can't add KrontelliNSE; instead
  route payloads with a `kt` block inside the existing `OneSignalNotificationServiceExtension` (post the
  `received` receipt, attach `image_url`) and pass everything else to OneSignal. No new target or profile.
- **Android background display.** Krontelli sends FCM *notification* messages, so Android shows them
  itself while the app is in the background, whichever messaging service owns FCM. During a
  dual-SDK release the OneSignal service may still receive the message first; display is unaffected,
  but foreground display and open tracking must be tested on that build.
- **Foreground display** is handled by your `expo-notifications` `setNotificationHandler`, not by the
  SDK. OneSignal's `setNotificationWillShowInForegroundHandler` has no equivalent here.
- **Identity.** `OneSignal.login(externalId)` becomes `Krontelli.login(identityToken)` with a token
  minted by your backend — the device can no longer claim an arbitrary user id.
- **Tags and user properties** are set from your backend with the server key, not from the device.
- **Tokens** are native APNs / FCM tokens; nothing is routed through Expo's push service or OneSignal.
- **Receipts** replace OneSignal's confirmed delivery; Android has no background `received`.

## Development

```sh
pnpm --filter @krontelli/sdk-react-native test        # vitest: queue, HTTP client, payload parsing, credentials, client
pnpm --filter @krontelli/sdk-react-native typecheck
pnpm --filter @krontelli/sdk-react-native build       # tsc → build/
```

The pure logic is tested through a `PlatformAdapter` interface (`src/platform/types.ts`);
`MemoryPlatform` is exported for apps that want to test their own integration without Expo modules.
