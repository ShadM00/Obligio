// Expo config plugin entry point. Usage in app.json / app.config.js:
//   "plugins": [["@krontelli/sdk-react-native", { "apiBaseUrl": "https://api.krontelli.com" }]]
module.exports = require("./plugin/withKrontelli");
