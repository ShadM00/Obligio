/**
 * Events module: track(), screen(), the automatic lifecycle events and the flush schedule.
 *
 * Automatic events:
 *  - first_open     first launch of this installation (flag in AsyncStorage)
 *  - app_open       every cold start
 *  - app_update     stored app version differs from the running one ({ from, to })
 *  - session_start  cold start, and whenever the app returns to the foreground after > 30 s in background
 *  - screen_view    via screen(name)
 *  - push_received / push_opened are emitted by the push module through track()
 * `automatic: false` turns all of these off except screen_view, which only the app sends.
 */
import { HttpError, NetworkError } from "../core/http";
import type { InstallationManager } from "../core/installation";
import type { AppStateStatus, PlatformAdapter } from "../platform/types";
import type { EventProps, KrontelliLogger } from "../types";
import { EventFlusher, EventQueue, type EventBatch, type SendOutcome } from "./queue";

export const FIRST_OPEN_KEY = "krontelli.events.first_open.v1";
export const APP_VERSION_KEY = "krontelli.events.app_version.v1";
export const SESSION_GAP_MS = 30_000;

export interface EventsModuleOptions {
  platform: PlatformAdapter;
  installation: InstallationManager;
  log: KrontelliLogger;
  appVersion?: string;
  automatic?: boolean;
  flushIntervalMs?: number;
  flushAtCount?: number;
  maxEventAgeMs?: number;
  maxQueueLength?: number;
}

export interface IngestResult {
  received: number;
  stored: number;
  duplicates: number;
  flagged: number;
}

export class EventsModule {
  readonly queue: EventQueue;
  readonly flusher: EventFlusher;
  private readonly platform: PlatformAdapter;
  private readonly installation: InstallationManager;
  private readonly log: KrontelliLogger;
  private readonly appVersion: string | undefined;
  readonly automatic: boolean;
  private unsubscribeAppState: (() => void) | null = null;
  private backgroundedAt: number | null = null;
  private lastState: AppStateStatus;

  constructor(opts: EventsModuleOptions) {
    this.platform = opts.platform;
    this.installation = opts.installation;
    this.log = opts.log;
    this.appVersion = opts.appVersion;
    this.automatic = opts.automatic ?? true;
    this.lastState = opts.platform.appState.current();
    this.queue = new EventQueue({
      storage: opts.platform.storage,
      now: () => opts.platform.now(),
      log: opts.log,
      maxEventAgeMs: opts.maxEventAgeMs,
      maxQueueLength: opts.maxQueueLength,
    });
    this.flusher = new EventFlusher({
      queue: this.queue,
      send: (batch) => this.send(batch),
      now: () => opts.platform.now(),
      log: opts.log,
      flushIntervalMs: opts.flushIntervalMs,
      flushAtCount: opts.flushAtCount,
    });
  }

  /** Queue an event. Safe before start(); it is persisted once the queue has loaded. */
  track(name: string, props?: EventProps): void {
    if (typeof name !== "string" || name.length === 0 || name.length > 128) {
      this.log.warn("track(): event name must be 1–128 characters; ignored", name);
      return;
    }
    const now = this.platform.now();
    const ok = this.queue.enqueue({
      event_id: this.platform.randomUUID(),
      name,
      ...(props !== undefined ? { props } : {}),
      client_ts: new Date(now).toISOString(),
      queued_at: now,
    });
    if (ok) this.flusher.notifyEnqueued();
  }

  screen(name: string, props?: EventProps): void {
    this.track("screen_view", { ...(props ?? {}), screen: name });
  }

  flush(): Promise<void> {
    return this.flusher.flush(true);
  }

  /** Restore the queue, emit launch events and start the schedule. */
  async start(): Promise<void> {
    await this.queue.load();
    if (this.automatic) await this.emitLaunchEvents();
    this.unsubscribeAppState = this.platform.appState.subscribe((state) => this.onAppState(state));
    this.flusher.start();
  }

  stop(): void {
    this.flusher.stop();
    this.unsubscribeAppState?.();
    this.unsubscribeAppState = null;
  }

  private async emitLaunchEvents(): Promise<void> {
    const storage = this.platform.storage;
    const [firstOpen, lastVersion] = await Promise.all([
      storage.getItem(FIRST_OPEN_KEY).catch(() => null),
      storage.getItem(APP_VERSION_KEY).catch(() => null),
    ]);
    const version = this.appVersion ?? this.platform.deviceInfo().app_version ?? null;
    if (!firstOpen) {
      this.track("first_open");
      await storage.setItem(FIRST_OPEN_KEY, String(this.platform.now())).catch(() => undefined);
    } else if (version && lastVersion && lastVersion !== version) {
      this.track("app_update", { from: lastVersion, to: version });
    }
    if (version && version !== lastVersion) await storage.setItem(APP_VERSION_KEY, version).catch(() => undefined);
    this.track("app_open");
    this.track("session_start");
  }

  private onAppState(state: AppStateStatus): void {
    const prev = this.lastState;
    this.lastState = state;
    if (state === "background" || state === "inactive") {
      if (prev === "active") {
        this.backgroundedAt = this.platform.now();
        void this.flusher.flush(true);
      }
      return;
    }
    if (state === "active" && prev !== "active") {
      const away = this.backgroundedAt === null ? 0 : this.platform.now() - this.backgroundedAt;
      this.backgroundedAt = null;
      if (this.automatic && away > SESSION_GAP_MS) this.track("session_start", { background_ms: away });
      void this.flusher.flush();
    }
  }

  /** POST /v1/events and map the response to a flusher outcome. */
  private async send(batch: EventBatch): Promise<SendOutcome> {
    try {
      const result = await this.installation.authorized<IngestResult>("POST", "/v1/events", { body: batch, retries: 0 });
      if (result && (result.flagged > 0 || result.duplicates > 0)) {
        this.log.debug(`events accepted: stored=${result.stored} duplicates=${result.duplicates} flagged=${result.flagged}`);
      }
      return { kind: "ok" };
    } catch (err) {
      if (err instanceof NetworkError) return { kind: "retry" };
      if (err instanceof HttpError) {
        if (err.status === 503 || err.status === 429 || err.status >= 500 || err.status === 408) {
          return { kind: "retry", retryAfterMs: err.retryAfterMs };
        }
        // 401 was already handled by re-enrolment inside authorized(); if it still fails, retry later.
        if (err.status === 401) return { kind: "retry" };
        // 400/413 etc.: the batch will never be accepted.
        return { kind: "drop", reason: `${err.status} ${err.code ?? ""} ${err.message}`.trim() };
      }
      return { kind: "retry" };
    }
  }
}
