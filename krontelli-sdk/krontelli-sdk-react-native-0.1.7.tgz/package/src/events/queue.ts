/**
 * On-device event queue. Pure logic: storage, clock and the sender are injected.
 *
 * Rules (design doc, "Ingestion rules" and the 7-day drop rule):
 *  - a batch is ≤ 100 events and ≤ 256 KB; one event is ≤ 32 KB (oversize events are dropped);
 *  - an event older than 7 days is dropped instead of sent, so the server's 14-day dedup window
 *    always covers a retried event_id;
 *  - event_id is a UUID v4 minted on the device; retries are idempotent on it;
 *  - the queue is persisted to AsyncStorage as one JSON document and survives restarts;
 *  - 503 (+ Retry-After) keeps the batch queued and backs off; other 5xx/network errors back off
 *    exponentially; 4xx other than 401/429 drops the batch (it will never be accepted).
 */
import { computeBackoffMs } from "../core/backoff";
import type { KeyValueStorage } from "../platform/types";
import type { EventProps, KrontelliLogger } from "../types";

export const QUEUE_KEY = "krontelli.events.v1";
export const MAX_BATCH_EVENTS = 100;
export const MAX_BATCH_BYTES = 256 * 1024;
export const MAX_EVENT_BYTES = 32 * 1024;
export const DEFAULT_MAX_EVENT_AGE_MS = 7 * 24 * 60 * 60_000;
export const DEFAULT_MAX_QUEUE_LENGTH = 1000;

export interface QueuedEvent {
  event_id: string;
  name: string;
  props?: EventProps;
  client_ts: string;
  /** ms epoch when the event was queued; used for the 7-day drop rule. */
  queued_at: number;
}

export type WireEvent = Omit<QueuedEvent, "queued_at">;

export interface EventBatch {
  schema_version: 1;
  events: WireEvent[];
}

export function toWire(ev: QueuedEvent): WireEvent {
  const out: WireEvent = { event_id: ev.event_id, name: ev.name, client_ts: ev.client_ts };
  if (ev.props !== undefined) out.props = ev.props;
  return out;
}

/** UTF-8 byte length without relying on TextEncoder (not always present in older RN runtimes). */
export function utf8Length(s: string): number {
  let bytes = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 0x80) bytes += 1;
    else if (c < 0x800) bytes += 2;
    else if (c >= 0xd800 && c <= 0xdbff) {
      bytes += 4;
      i++; // surrogate pair
    } else bytes += 3;
  }
  return bytes;
}

export interface EventQueueOptions {
  storage: KeyValueStorage;
  now: () => number;
  log: KrontelliLogger;
  maxEventAgeMs?: number;
  maxQueueLength?: number;
  storageKey?: string;
}

export class EventQueue {
  private readonly storage: KeyValueStorage;
  private readonly now: () => number;
  private readonly log: KrontelliLogger;
  private readonly maxAge: number;
  private readonly maxLength: number;
  private readonly key: string;
  private items: QueuedEvent[] = [];
  private loaded = false;
  private persisting: Promise<void> = Promise.resolve();
  private dirty = false;

  constructor(opts: EventQueueOptions) {
    this.storage = opts.storage;
    this.now = opts.now;
    this.log = opts.log;
    this.maxAge = opts.maxEventAgeMs ?? DEFAULT_MAX_EVENT_AGE_MS;
    this.maxLength = opts.maxQueueLength ?? DEFAULT_MAX_QUEUE_LENGTH;
    this.key = opts.storageKey ?? QUEUE_KEY;
  }

  get length(): number {
    return this.items.length;
  }

  /** Hydrate from storage. Restored events are placed ahead of any queued before load() finished. */
  async load(): Promise<void> {
    if (this.loaded) return;
    this.loaded = true;
    let restored: QueuedEvent[] = [];
    try {
      const raw = await this.storage.getItem(this.key);
      if (raw) {
        const parsed = JSON.parse(raw) as unknown;
        if (Array.isArray(parsed)) restored = parsed.filter(isQueuedEvent);
      }
    } catch (err) {
      this.log.warn("event queue restore failed; starting empty", err);
    }
    const pendingSinceStart = this.items;
    this.items = [...restored, ...pendingSinceStart];
    this.dropExpired();
    if (pendingSinceStart.length > 0) this.schedulePersist();
  }

  /** Append an event. Oversize events are dropped with a warning; the queue is capped at maxQueueLength (oldest dropped). */
  enqueue(ev: QueuedEvent): boolean {
    const size = utf8Length(JSON.stringify(toWire(ev)));
    if (size > MAX_EVENT_BYTES) {
      this.log.warn(`event "${ev.name}" is ${size} bytes (> ${MAX_EVENT_BYTES}); dropped`);
      return false;
    }
    this.items.push(ev);
    if (this.items.length > this.maxLength) {
      const overflow = this.items.length - this.maxLength;
      this.items.splice(0, overflow);
      this.log.warn(`event queue full; dropped ${overflow} oldest event(s)`);
    }
    this.schedulePersist();
    return true;
  }

  /** Remove events older than maxAge. Returns how many were dropped. */
  dropExpired(): number {
    const cutoff = this.now() - this.maxAge;
    const before = this.items.length;
    this.items = this.items.filter((e) => e.queued_at >= cutoff);
    const dropped = before - this.items.length;
    if (dropped > 0) {
      this.log.warn(`dropped ${dropped} event(s) older than ${Math.round(this.maxAge / 86_400_000)} days`);
      this.schedulePersist();
    }
    return dropped;
  }

  /** Next batch within the size limits, after applying the drop rule. Does not remove events; call ack() after a 2xx. */
  nextBatch(): QueuedEvent[] {
    this.dropExpired();
    const batch: QueuedEvent[] = [];
    // 2 bytes for "[]" plus the fixed envelope; commas are 1 byte each.
    let bytes = utf8Length(JSON.stringify({ schema_version: 1, events: [] }));
    for (const ev of this.items) {
      if (batch.length >= MAX_BATCH_EVENTS) break;
      const size = utf8Length(JSON.stringify(toWire(ev))) + 1;
      if (bytes + size > MAX_BATCH_BYTES && batch.length > 0) break;
      batch.push(ev);
      bytes += size;
    }
    return batch;
  }

  /** Remove acknowledged (or permanently rejected) events. */
  ack(eventIds: Iterable<string>): void {
    const ids = new Set(eventIds);
    if (ids.size === 0) return;
    this.items = this.items.filter((e) => !ids.has(e.event_id));
    this.schedulePersist();
  }

  snapshot(): readonly QueuedEvent[] {
    return this.items;
  }

  /** Resolves when the latest state has been written. */
  async persisted(): Promise<void> {
    await this.persisting;
  }

  private schedulePersist(): void {
    if (!this.loaded) return; // persisted together once load() has merged restored events
    this.dirty = true;
    this.persisting = this.persisting.then(async () => {
      if (!this.dirty) return;
      this.dirty = false;
      try {
        await this.storage.setItem(this.key, JSON.stringify(this.items));
      } catch (err) {
        this.log.warn("event queue persist failed", err);
      }
    });
  }
}

function isQueuedEvent(v: unknown): v is QueuedEvent {
  if (!v || typeof v !== "object") return false;
  const e = v as Record<string, unknown>;
  return typeof e.event_id === "string" && typeof e.name === "string" && typeof e.client_ts === "string" && typeof e.queued_at === "number";
}

/** Outcome of sending one batch, as the flusher needs it. */
export type SendOutcome =
  | { kind: "ok" }
  | { kind: "retry"; retryAfterMs?: number }
  | { kind: "drop"; reason: string };

export interface EventFlusherOptions {
  queue: EventQueue;
  send: (batch: EventBatch) => Promise<SendOutcome>;
  now: () => number;
  log: KrontelliLogger;
  flushIntervalMs?: number;
  flushAtCount?: number;
  random?: () => number;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (handle: unknown) => void;
}

/**
 * Drives the queue: flush every `flushIntervalMs`, when `flushAtCount` events are waiting, on demand
 * (flush()) and when the app goes to background. Single-flight with exponential backoff.
 */
export class EventFlusher {
  private readonly queue: EventQueue;
  private readonly send: (batch: EventBatch) => Promise<SendOutcome>;
  private readonly now: () => number;
  private readonly log: KrontelliLogger;
  private readonly intervalMs: number;
  private readonly flushAtCount: number;
  private readonly random: () => number;
  private readonly setTimer: (fn: () => void, ms: number) => unknown;
  private readonly clearTimer: (handle: unknown) => void;
  private timer: unknown = null;
  private inflight: Promise<void> | null = null;
  private failures = 0;
  private nextAllowedAt = 0;
  private running = false;

  constructor(opts: EventFlusherOptions) {
    this.queue = opts.queue;
    this.send = opts.send;
    this.now = opts.now;
    this.log = opts.log;
    this.intervalMs = opts.flushIntervalMs ?? 10_000;
    this.flushAtCount = opts.flushAtCount ?? 20;
    this.random = opts.random ?? Math.random;
    this.setTimer = opts.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = opts.clearTimer ?? ((h) => clearTimeout(h as ReturnType<typeof setTimeout>));
  }

  get backoffUntil(): number {
    return this.nextAllowedAt;
  }

  start(): void {
    if (this.running) return;
    this.running = true;
    this.scheduleTick();
  }

  stop(): void {
    this.running = false;
    if (this.timer !== null) {
      this.clearTimer(this.timer);
      this.timer = null;
    }
  }

  /** Called after each enqueue. */
  notifyEnqueued(): void {
    if (this.queue.length >= this.flushAtCount) void this.flush();
  }

  /** Flush everything that is allowed right now (respects backoff unless force=true). */
  flush(force = false): Promise<void> {
    if (this.inflight) return this.inflight;
    this.inflight = this.run(force).finally(() => {
      this.inflight = null;
    });
    return this.inflight;
  }

  private async run(force: boolean): Promise<void> {
    if (!force && this.now() < this.nextAllowedAt) return;
    for (;;) {
      const batch = this.queue.nextBatch();
      if (batch.length === 0) return;
      const wire: EventBatch = { schema_version: 1, events: batch.map(toWire) };
      let outcome: SendOutcome;
      try {
        outcome = await this.send(wire);
      } catch (err) {
        this.log.warn("event send threw; treating as retry", err);
        outcome = { kind: "retry" };
      }
      if (outcome.kind === "ok") {
        this.failures = 0;
        this.nextAllowedAt = 0;
        this.queue.ack(batch.map((e) => e.event_id));
        continue; // more batches may be waiting
      }
      if (outcome.kind === "drop") {
        this.log.warn(`dropping ${batch.length} event(s): ${outcome.reason}`);
        this.queue.ack(batch.map((e) => e.event_id));
        continue;
      }
      const wait = computeBackoffMs(this.failures, outcome.retryAfterMs, { random: this.random });
      this.failures += 1;
      this.nextAllowedAt = this.now() + wait;
      this.log.debug(`event flush deferred ${wait}ms (${this.queue.length} queued)`);
      return;
    }
  }

  private scheduleTick(): void {
    if (!this.running) return;
    this.timer = this.setTimer(() => {
      this.timer = null;
      void this.flush().finally(() => this.scheduleTick());
    }, this.intervalMs);
  }
}
