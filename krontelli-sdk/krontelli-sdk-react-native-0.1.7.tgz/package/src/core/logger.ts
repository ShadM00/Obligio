import type { KrontelliLogger } from "../types";

const noop = () => undefined;

export function createLogger(custom: Partial<KrontelliLogger> | undefined, isDev: boolean): KrontelliLogger {
  const prefix = "[krontelli]";
  const base: KrontelliLogger = {
    debug: isDev ? (...a) => console.debug(prefix, ...a) : noop,
    info: isDev ? (...a) => console.info(prefix, ...a) : noop,
    warn: (...a) => console.warn(prefix, ...a),
    error: (...a) => console.error(prefix, ...a),
  };
  return { ...base, ...(custom ?? {}) };
}
