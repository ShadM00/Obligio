/**
 * Installation credential storage. The credential ("kt_ins_<uuid>.<secret>") is returned once by
 * POST /v1/installations and lives in expo-secure-store (Keychain / Keystore). If secure storage is
 * unavailable we fall back to AsyncStorage and warn once: the credential is then only as safe as
 * the app sandbox.
 *
 * Rotation swaps the stored record in a single write. If the write fails we keep the old
 * credential in memory and on disk; the server honours it for 10 more minutes, which covers a retry.
 */
import type { KeyValueStorage } from "../platform/types";
import type { KrontelliLogger } from "../types";

export const CREDENTIAL_KEY = "krontelli.installation.v1";

export interface StoredCredential {
  installation_id: string;
  credential: string;
  secret_version: number;
  /** ms epoch when this credential was issued (registration or rotation). */
  issued_at: number;
}

export function installationIdFromCredential(credential: string): string | null {
  // kt_ins_<uuid>.<secret>
  const m = /^kt_ins_([0-9a-fA-F-]{36})\./.exec(credential);
  return m ? (m[1] as string) : null;
}

export class CredentialStore {
  private readonly secure: KeyValueStorage | null;
  private readonly fallback: KeyValueStorage;
  private readonly log: KrontelliLogger;
  private warned = false;
  private cached: StoredCredential | null | undefined;

  constructor(secure: KeyValueStorage | null, fallback: KeyValueStorage, log: KrontelliLogger) {
    this.secure = secure;
    this.fallback = fallback;
    this.log = log;
  }

  get current(): StoredCredential | null {
    return this.cached ?? null;
  }

  private store(): KeyValueStorage {
    if (this.secure) return this.secure;
    if (!this.warned) {
      this.warned = true;
      this.log.warn("expo-secure-store is unavailable; the installation credential is stored in AsyncStorage. Install expo-secure-store for Keychain/Keystore protection.");
    }
    return this.fallback;
  }

  async load(): Promise<StoredCredential | null> {
    if (this.cached !== undefined) return this.cached;
    let raw: string | null = null;
    if (this.secure) {
      try {
        raw = await this.secure.getItem(CREDENTIAL_KEY);
      } catch (err) {
        this.log.warn("secure-store read failed, trying AsyncStorage", err);
      }
    }
    let fromFallback = false;
    if (raw === null) {
      raw = await this.fallback.getItem(CREDENTIAL_KEY);
      fromFallback = raw !== null;
    }
    const parsed = raw ? safeParse(raw) : null;
    this.cached = parsed;
    // Credential found in the insecure fallback while secure storage now works: migrate it.
    if (parsed && fromFallback && this.secure) {
      try {
        await this.secure.setItem(CREDENTIAL_KEY, JSON.stringify(parsed));
        await this.fallback.removeItem(CREDENTIAL_KEY);
      } catch (err) {
        this.log.warn("could not migrate credential into secure storage", err);
      }
    }
    return parsed;
  }

  /** Persist then swap the in-memory credential. Throws (and leaves the old credential) if the write fails. */
  async save(next: StoredCredential): Promise<void> {
    await this.store().setItem(CREDENTIAL_KEY, JSON.stringify(next));
    this.cached = next;
  }

  async clear(): Promise<void> {
    this.cached = null;
    await Promise.all([
      this.secure?.removeItem(CREDENTIAL_KEY).catch(() => undefined),
      this.fallback.removeItem(CREDENTIAL_KEY).catch(() => undefined),
    ]);
  }
}

function safeParse(raw: string): StoredCredential | null {
  try {
    const v = JSON.parse(raw) as Partial<StoredCredential>;
    if (typeof v.credential !== "string" || typeof v.installation_id !== "string") return null;
    return {
      installation_id: v.installation_id,
      credential: v.credential,
      secret_version: typeof v.secret_version === "number" ? v.secret_version : 1,
      issued_at: typeof v.issued_at === "number" ? v.issued_at : 0,
    };
  } catch {
    return null;
  }
}
