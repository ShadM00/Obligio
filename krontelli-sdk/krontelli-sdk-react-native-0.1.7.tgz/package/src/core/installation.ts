/**
 * Installation identity.
 *
 *  - First launch: POST /v1/installations with the public key, store the credential once.
 *  - Every launch: PATCH /v1/installations/me with os/app/sdk version, timezone and locale
 *    (skipped when nothing changed in the last 24 h).
 *  - Rotation: POST /v1/installations/me/rotate; the old credential stays valid for 10 minutes, so
 *    the swap is "write new record, then switch in memory" and a failed write just keeps the old one.
 *  - Re-enrol rule: a 401 on any call other than login means the server no longer recognises the
 *    installation (revoked or lost). We clear the credential, register a fresh installation and retry
 *    the call once. The app re-links the person on its next login(); until then the installation is
 *    anonymous. Login 401s are returned to the app because they usually mean the identity token is bad.
 */
import type { PlatformAdapter } from "../platform/types";
import type { KrontelliLogger, Platform } from "../types";
import { SDK_VERSION } from "../version";
import { CredentialStore, type StoredCredential, installationIdFromCredential } from "./credentials";
import { HttpClient, HttpError, type RequestOptions } from "./http";

export const DEVICE_INFO_KEY = "krontelli.device_info.v1";
const DEVICE_INFO_REFRESH_MS = 24 * 60 * 60_000;

export interface DeviceInfoPayload {
  os_version?: string;
  app_version?: string;
  sdk_version: string;
  timezone?: string;
  locale?: string;
}

export interface InstallationEvents {
  /** New installation created (first launch or re-enrol). `reenrolled` is true when an old one was replaced. */
  onRegistered?: (installation: StoredCredential, reenrolled: boolean) => void;
}

export interface InstallationManagerOptions {
  http: HttpClient;
  platform: PlatformAdapter;
  publicKey: string;
  credentials: CredentialStore;
  log: KrontelliLogger;
  appVersion?: string;
  /** 0 disables automatic rotation. */
  rotationDays: number;
  events?: InstallationEvents;
}

export interface AuthorizedRequestOptions extends RequestOptions {
  /** Login calls never trigger re-enrolment on 401. */
  isLogin?: boolean;
}

export class InstallationManager {
  private readonly http: HttpClient;
  private readonly platform: PlatformAdapter;
  private readonly publicKey: string;
  private readonly credentials: CredentialStore;
  private readonly log: KrontelliLogger;
  private readonly appVersion: string | undefined;
  private readonly rotationDays: number;
  private readonly events: InstallationEvents;
  private registering: Promise<StoredCredential> | null = null;

  constructor(opts: InstallationManagerOptions) {
    this.http = opts.http;
    this.platform = opts.platform;
    this.publicKey = opts.publicKey;
    this.credentials = opts.credentials;
    this.log = opts.log;
    this.appVersion = opts.appVersion;
    this.rotationDays = opts.rotationDays;
    this.events = opts.events ?? {};
  }

  get installationId(): string | null {
    return this.credentials.current?.installation_id ?? null;
  }

  get credential(): StoredCredential | null {
    return this.credentials.current;
  }

  deviceInfo(): DeviceInfoPayload {
    const info = this.platform.deviceInfo();
    const out: DeviceInfoPayload = { sdk_version: SDK_VERSION };
    if (info.os_version) out.os_version = info.os_version;
    const appVersion = this.appVersion ?? info.app_version;
    if (appVersion) out.app_version = appVersion;
    if (info.timezone) out.timezone = info.timezone;
    if (info.locale) out.locale = info.locale;
    return out;
  }

  /** Loads the stored credential or registers a new installation. Single-flight. */
  async ensureRegistered(): Promise<StoredCredential> {
    const existing = await this.credentials.load();
    if (existing) return existing;
    return this.register(false);
  }

  private register(reenrol: boolean): Promise<StoredCredential> {
    if (this.registering) return this.registering;
    this.registering = (async () => {
      try {
        const platform: Platform = this.platform.platform;
        const res = await this.http.request<{ installation_id: string; credential: string }>("POST", "/v1/installations", {
          auth: this.publicKey,
          body: { platform, ...this.deviceInfo() },
          retries: 3,
        });
        const stored: StoredCredential = {
          installation_id: res.data.installation_id ?? installationIdFromCredential(res.data.credential) ?? "",
          credential: res.data.credential,
          secret_version: 1,
          issued_at: this.platform.now(),
        };
        await this.credentials.save(stored);
        await this.platform.storage.removeItem(DEVICE_INFO_KEY).catch(() => undefined);
        this.log.info(reenrol ? "installation re-enrolled" : "installation registered", stored.installation_id);
        this.events.onRegistered?.(stored, reenrol);
        return stored;
      } finally {
        this.registering = null;
      }
    })();
    return this.registering;
  }

  /** Clear the local credential and register again. Used for the 401 re-enrol rule. */
  async reenrol(): Promise<StoredCredential> {
    if (this.registering) return this.registering;
    await this.credentials.clear();
    return this.register(true);
  }

  /**
   * Request with the installation credential. On 401 (non-login) clears the credential, re-enrols
   * and retries once with the new credential.
   */
  async authorized<T = unknown>(method: string, path: string, opts: AuthorizedRequestOptions = {}): Promise<T> {
    const cred = await this.ensureRegistered();
    try {
      const res = await this.http.request<T>(method, path, { ...opts, auth: cred.credential });
      return res.data;
    } catch (err) {
      if (!(err instanceof HttpError) || err.status !== 401) throw err;
      // Login: a 401 is almost always a bad identity token, but the auth hook can also reject the
      // installation itself; only that case re-enrols.
      if (opts.isLogin && !/installation/i.test(err.message)) throw err;
      this.log.warn("installation credential rejected (401); re-enrolling", err.message);
      const fresh = await this.reenrol();
      if (opts.isLogin) throw err; // the app must call login() again with a fresh token
      const res = await this.http.request<T>(method, path, { ...opts, auth: fresh.credential });
      return res.data;
    }
  }

  /** PATCH device info when it changed or the last report is older than 24 h. */
  async syncDeviceInfo(force = false): Promise<boolean> {
    const payload = this.deviceInfo();
    const serialized = JSON.stringify(payload);
    if (!force) {
      const last = await this.platform.storage.getItem(DEVICE_INFO_KEY).catch(() => null);
      if (last) {
        try {
          const parsed = JSON.parse(last) as { payload: string; at: number };
          if (parsed.payload === serialized && this.platform.now() - parsed.at < DEVICE_INFO_REFRESH_MS) return false;
        } catch {
          /* fallthrough: resend */
        }
      }
    }
    await this.authorized("PATCH", "/v1/installations/me", { body: payload, retries: 1 });
    await this.platform.storage.setItem(DEVICE_INFO_KEY, JSON.stringify({ payload: serialized, at: this.platform.now() })).catch(() => undefined);
    return true;
  }

  /** POST /v1/installations/me/rotate and swap the stored credential. */
  async rotate(): Promise<StoredCredential> {
    const current = await this.ensureRegistered();
    const res = await this.http.request<{ credential: string; secret_version: number }>("POST", "/v1/installations/me/rotate", {
      auth: current.credential,
      retries: 1,
    });
    const next: StoredCredential = {
      installation_id: current.installation_id,
      credential: res.data.credential,
      secret_version: res.data.secret_version,
      issued_at: this.platform.now(),
    };
    try {
      await this.credentials.save(next);
    } catch (err) {
      // The old secret is still valid for 10 minutes; keep using it and let the next launch retry.
      this.log.warn("could not persist rotated credential; keeping the previous one", err);
      throw err;
    }
    return next;
  }

  /** Rotate when the credential is older than `rotationDays`. Never throws. */
  async maybeRotate(): Promise<void> {
    if (this.rotationDays <= 0) return;
    const cred = this.credentials.current;
    if (!cred || !cred.issued_at) return;
    const ageMs = this.platform.now() - cred.issued_at;
    if (ageMs < this.rotationDays * 24 * 60 * 60_000) return;
    try {
      await this.rotate();
      this.log.debug("installation credential rotated");
    } catch (err) {
      this.log.warn("credential rotation failed", err);
    }
  }
}
