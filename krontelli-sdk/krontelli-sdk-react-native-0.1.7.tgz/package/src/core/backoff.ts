/** Exponential backoff with full jitter; honours a server-supplied Retry-After when present. */
export interface BackoffOptions {
  baseMs?: number;
  maxMs?: number;
  random?: () => number;
}

export function computeBackoffMs(attempt: number, retryAfterMs: number | undefined, opts: BackoffOptions = {}): number {
  const base = opts.baseMs ?? 1000;
  const max = opts.maxMs ?? 5 * 60_000;
  const random = opts.random ?? Math.random;
  if (retryAfterMs !== undefined && retryAfterMs > 0) {
    // Retry-After is authoritative: wait at least that long, plus up to 20% jitter so clients don't stampede.
    return Math.min(max, Math.round(retryAfterMs * (1 + random() * 0.2)));
  }
  const exp = Math.min(max, base * Math.pow(2, Math.max(0, attempt)));
  return Math.round(exp * (0.5 + random() * 0.5));
}

/** Parses an HTTP Retry-After header (delta-seconds or HTTP-date) into milliseconds. */
export function parseRetryAfterMs(value: string | null | undefined, now: number = Date.now()): number | undefined {
  if (!value) return undefined;
  const trimmed = value.trim();
  if (/^\d+$/.test(trimmed)) return Number(trimmed) * 1000;
  const date = Date.parse(trimmed);
  if (Number.isNaN(date)) return undefined;
  return Math.max(0, date - now);
}
