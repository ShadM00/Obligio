/**
 * Small HTTP client around fetch: JSON bodies, bearer auth, per-request timeout, and bounded retry
 * with backoff on 503 (honouring Retry-After), 429 and network errors. 4xx other than 429 is never retried.
 * Callers that run their own retry loop (the event queue) pass `retries: 0` and read `retryAfterMs`
 * off the thrown HttpError.
 */
import { computeBackoffMs, parseRetryAfterMs } from "./backoff";

export class HttpError extends Error {
  readonly status: number;
  readonly code: string | undefined;
  readonly retryAfterMs: number | undefined;
  readonly body: unknown;
  constructor(status: number, message: string, opts: { code?: string; retryAfterMs?: number; body?: unknown } = {}) {
    super(message);
    this.name = "HttpError";
    this.status = status;
    this.code = opts.code;
    this.retryAfterMs = opts.retryAfterMs;
    this.body = opts.body;
  }
  /** 503/429/408 and 5xx are safe to retry for idempotent calls. */
  get retryable(): boolean {
    return this.status === 503 || this.status === 429 || this.status === 408 || this.status >= 500;
  }
}

/** Network failure or timeout: status 0. */
export class NetworkError extends Error {
  readonly cause: unknown;
  constructor(message: string, cause?: unknown) {
    super(message);
    this.name = "NetworkError";
    this.cause = cause;
  }
}

export interface HttpClientOptions {
  baseUrl: string;
  fetch: typeof fetch;
  timeoutMs?: number;
  /** Default retry count for retryable failures. */
  retries?: number;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  userAgent?: string;
}

export interface RequestOptions {
  body?: unknown;
  /** Bearer token value (public key, installation credential or receipt token). */
  auth?: string;
  retries?: number;
  timeoutMs?: number;
  headers?: Record<string, string>;
}

export interface HttpResponse<T> {
  status: number;
  data: T;
  headers: Headers;
}

const defaultSleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export class HttpClient {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly timeoutMs: number;
  private readonly retries: number;
  private readonly now: () => number;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly random: () => number;
  private readonly userAgent: string | undefined;

  constructor(opts: HttpClientOptions) {
    this.baseUrl = opts.baseUrl.replace(/\/+$/, "");
    this.fetchImpl = opts.fetch;
    this.timeoutMs = opts.timeoutMs ?? 15_000;
    this.retries = opts.retries ?? 2;
    this.now = opts.now ?? (() => Date.now());
    this.sleep = opts.sleep ?? defaultSleep;
    this.random = opts.random ?? Math.random;
    this.userAgent = opts.userAgent;
  }

  async request<T = unknown>(method: string, path: string, opts: RequestOptions = {}): Promise<HttpResponse<T>> {
    const retries = opts.retries ?? this.retries;
    let attempt = 0;
    for (;;) {
      try {
        return await this.once<T>(method, path, opts);
      } catch (err) {
        const retryable = err instanceof NetworkError || (err instanceof HttpError && err.retryable);
        if (!retryable || attempt >= retries) throw err;
        const retryAfter = err instanceof HttpError ? err.retryAfterMs : undefined;
        await this.sleep(computeBackoffMs(attempt, retryAfter, { random: this.random, maxMs: 60_000 }));
        attempt += 1;
      }
    }
  }

  private async once<T>(method: string, path: string, opts: RequestOptions): Promise<HttpResponse<T>> {
    const headers: Record<string, string> = { Accept: "application/json", ...(opts.headers ?? {}) };
    if (opts.body !== undefined) headers["Content-Type"] = "application/json";
    if (opts.auth) headers.Authorization = `Bearer ${opts.auth}`;
    if (this.userAgent) headers["X-Krontelli-SDK"] = this.userAgent;

    const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    const timeoutMs = opts.timeoutMs ?? this.timeoutMs;
    const timer = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
    let res: Response;
    try {
      res = await this.fetchImpl(`${this.baseUrl}${path}`, {
        method,
        headers,
        body: opts.body === undefined ? undefined : JSON.stringify(opts.body),
        signal: controller?.signal,
      });
    } catch (err) {
      const aborted = (err as { name?: string } | null)?.name === "AbortError";
      throw new NetworkError(aborted ? `request timed out after ${timeoutMs}ms` : `network error: ${(err as Error)?.message ?? String(err)}`, err);
    } finally {
      if (timer) clearTimeout(timer);
    }

    const text = await res.text().catch(() => "");
    let data: unknown = null;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
    }
    if (res.ok) return { status: res.status, data: data as T, headers: res.headers };

    const body = (data && typeof data === "object" ? data : {}) as { error?: string; message?: string; retry_after?: number };
    const retryAfterHeader = parseRetryAfterMs(res.headers.get("retry-after"), this.now());
    const retryAfterMs = retryAfterHeader ?? (typeof body.retry_after === "number" ? body.retry_after * 1000 : undefined);
    throw new HttpError(res.status, body.message ?? `HTTP ${res.status}`, { code: body.error, retryAfterMs, body: data });
  }
}
