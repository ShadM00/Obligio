/**
 * Optional diagnostics bridge. If the app passes its `@sentry/react-native` module (or the GlitchTip
 * flavour of it) to init({ sentry }), errors are tagged with the installation id and, when linked,
 * the person. No import of Sentry anywhere: this is duck-typed on `setUser`.
 */
import type { KrontelliLogger, SentryLike } from "../types";

export class DiagnosticsBridge {
  private readonly sentry: SentryLike | undefined;
  private readonly log: KrontelliLogger;
  private installationId: string | null = null;
  private person: { person_id: string; external_id: string } | null = null;

  constructor(sentry: SentryLike | undefined, log: KrontelliLogger) {
    this.sentry = sentry;
    this.log = log;
  }

  setInstallation(installationId: string): void {
    this.installationId = installationId;
    this.person = null;
    this.apply();
  }

  setPerson(person: { person_id: string; external_id: string }): void {
    this.person = person;
    this.apply();
  }

  clearPerson(): void {
    this.person = null;
    this.apply();
  }

  private apply(): void {
    if (!this.sentry || typeof this.sentry.setUser !== "function") return;
    try {
      if (!this.installationId) return;
      this.sentry.setUser({
        id: this.installationId,
        krontelli_installation_id: this.installationId,
        ...(this.person ? { krontelli_person_id: this.person.person_id, username: this.person.external_id } : {}),
      });
    } catch (err) {
      this.log.warn("sentry.setUser failed", err);
    }
  }
}
