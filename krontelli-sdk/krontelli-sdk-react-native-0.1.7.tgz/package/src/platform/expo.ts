/**
 * Expo implementation of the platform adapter. Every Expo / React Native module is loaded with a
 * LITERAL `require("module")` inside its own try/catch. Metro (React Native's bundler) only follows
 * require calls whose argument is a string literal: a `require(name)` with a variable compiles but
 * throws "Requiring unknown module" on the device, and Metro reports that as a fatal error even
 * inside a try/catch. Never load a module through a variable, or from inside a function, here
 * (test/no-dynamic-require.test.ts guards both). The try/catch keeps the file importable in Node (tests, SSR) and lets optional modules
 * (expo-device, expo-application, expo-constants, expo-crypto, expo-localization) degrade when missing.
 *
 * Types below are minimal hand-written shapes of the parts of each module we touch; the SDK does
 * not depend on the modules' own type packages at build time.
 */
import type { OsPermission, Platform, PushEnvironment } from "../types";
import type { AppStateAdapter, AppStateStatus, DeviceInfo, DevicePushToken, KeyValueStorage, NotificationsAdapter, PlatformAdapter } from "./types";

declare const __DEV__: boolean | undefined;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type AnyModule = any;

interface RNModule {
  Platform: { OS: string; Version: string | number };
  AppState: {
    currentState: AppStateStatus | null;
    addEventListener(type: "change", handler: (s: AppStateStatus) => void): { remove(): void } | void;
    removeEventListener?(type: "change", handler: (s: AppStateStatus) => void): void;
  };
  NativeModules?: { I18nManager?: { localeIdentifier?: string }; SettingsManager?: { settings?: { AppleLocale?: string; AppleLanguages?: string[] } } };
}

function mapPermission(status: string | undefined, ios?: { status?: number } | null): OsPermission {
  // expo-notifications: PermissionStatus = "granted" | "denied" | "undetermined"; iOS also reports
  // IosAuthorizationStatus (3 = provisional, 4 = ephemeral).
  if (ios && (ios.status === 3 || ios.status === 4)) return "provisional";
  if (status === "granted") return "granted";
  if (status === "denied") return "denied";
  return "undetermined";
}

function createNotificationsAdapter(Notifications: AnyModule): NotificationsAdapter {
  const toToken = (t: { type: string; data: unknown }): DevicePushToken => ({ type: t.type, data: t.data });
  return {
    async getPermission() {
      const r = await Notifications.getPermissionsAsync();
      return mapPermission(r?.status, r?.ios);
    },
    async requestPermission() {
      const r = await Notifications.requestPermissionsAsync({
        ios: { allowAlert: true, allowBadge: true, allowSound: true },
      });
      return mapPermission(r?.status, r?.ios);
    },
    async getDevicePushToken() {
      // The NATIVE token (APNs hex / FCM registration token), not an ExponentPushToken.
      return toToken(await Notifications.getDevicePushTokenAsync());
    },
    addPushTokenListener(listener) {
      const sub = Notifications.addPushTokenListener((t: { type: string; data: unknown }) => listener(toToken(t)));
      return () => sub?.remove?.();
    },
    addNotificationReceivedListener(listener) {
      const sub = Notifications.addNotificationReceivedListener(listener);
      return () => sub?.remove?.();
    },
    addNotificationResponseReceivedListener(listener) {
      const sub = Notifications.addNotificationResponseReceivedListener(listener);
      return () => sub?.remove?.();
    },
    async getLastNotificationResponse() {
      if (typeof Notifications.getLastNotificationResponseAsync !== "function") return null;
      return (await Notifications.getLastNotificationResponseAsync()) ?? null;
    },
  };
}

function createSecureStorage(SecureStore: AnyModule): KeyValueStorage | null {
  if (!SecureStore || typeof SecureStore.getItemAsync !== "function") return null;
  // SecureStore keys may only contain [A-Za-z0-9._-]; ours do.
  const options = { keychainAccessible: SecureStore.AFTER_FIRST_UNLOCK_THIS_DEVICE_ONLY ?? SecureStore.AFTER_FIRST_UNLOCK };
  return {
    getItem: (key) => SecureStore.getItemAsync(key, options),
    setItem: (key, value) => SecureStore.setItemAsync(key, value, options),
    removeItem: (key) => SecureStore.deleteItemAsync(key, options),
  };
}

function createAppState(RN: RNModule | null): AppStateAdapter {
  if (!RN?.AppState) {
    return { current: () => "active", subscribe: () => () => undefined };
  }
  const AppState = RN.AppState;
  return {
    current: () => AppState.currentState ?? "unknown",
    subscribe(listener) {
      const sub = AppState.addEventListener("change", listener);
      return () => {
        if (sub && typeof (sub as { remove?: () => void }).remove === "function") (sub as { remove: () => void }).remove();
        else AppState.removeEventListener?.("change", listener);
      };
    },
  };
}

function detectLocale(RN: RNModule | null, Localization: AnyModule | null): string | undefined {
  try {
    const locales = Localization?.getLocales?.();
    const tag = locales?.[0]?.languageTag;
    if (typeof tag === "string" && tag) return tag;
  } catch {
    /* ignore */
  }
  try {
    const resolved = Intl.DateTimeFormat().resolvedOptions().locale;
    if (resolved && resolved !== "und") return resolved;
  } catch {
    /* ignore */
  }
  const nm = RN?.NativeModules;
  const ios = nm?.SettingsManager?.settings?.AppleLocale ?? nm?.SettingsManager?.settings?.AppleLanguages?.[0];
  const android = nm?.I18nManager?.localeIdentifier;
  const raw = ios ?? android;
  return typeof raw === "string" ? raw.replace("_", "-") : undefined;
}

function detectTimezone(Localization: AnyModule | null): string | undefined {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (tz) return tz;
  } catch {
    /* ignore */
  }
  try {
    const tz = Localization?.getCalendars?.()?.[0]?.timeZone ?? Localization?.timezone;
    if (typeof tz === "string") return tz;
  } catch {
    /* ignore */
  }
  return undefined;
}

function randomUUIDFactory(Crypto: AnyModule | null): () => string {
  if (Crypto && typeof Crypto.randomUUID === "function") return () => Crypto.randomUUID();
  const g = globalThis as { crypto?: { randomUUID?: () => string; getRandomValues?: (a: Uint8Array) => Uint8Array } };
  if (g.crypto && typeof g.crypto.randomUUID === "function") return () => g.crypto!.randomUUID!();
  if (g.crypto && typeof g.crypto.getRandomValues === "function") {
    return () => {
      const b = g.crypto!.getRandomValues!(new Uint8Array(16));
      b[6] = ((b[6] as number) & 0x0f) | 0x40;
      b[8] = ((b[8] as number) & 0x3f) | 0x80;
      const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
      return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
    };
  }
  // Last resort (Hermes without crypto and without expo-crypto): Math.random based v4.
  return () => {
    const h = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16));
    h[12] = "4";
    h[16] = ((parseInt(h[16] as string, 16) & 0x3) | 0x8).toString(16);
    const s = h.join("");
    return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20)}`;
  };
}

export interface ExpoPlatformOptions {
  /** Override the detected app version (init({ appVersion })). */
  appVersion?: string;
}

/*
 * These run while this file loads, never inside a function. Metro reports a missing module as fatal, ignoring any
 * try/catch, unless the require happens while another module is loading: its guard is only held then. Called from
 * init(), a missing optional module crashed Quick Poll at launch (expo-localization).
 */
/* eslint-disable @typescript-eslint/no-require-imports */
let RN: RNModule | null = null;
let AsyncStorageMod: AnyModule | null = null;
let SecureStore: AnyModule | null = null;
let Notifications: AnyModule | null = null;
let Device: AnyModule | null = null;
let Application: AnyModule | null = null;
let Constants: AnyModule | null = null;
let Crypto: AnyModule | null = null;
let Localization: AnyModule | null = null;
try { RN = require("react-native"); } catch { RN = null; }
try { AsyncStorageMod = require("@react-native-async-storage/async-storage"); } catch { AsyncStorageMod = null; }
try { SecureStore = require("expo-secure-store"); } catch { SecureStore = null; }
try { Notifications = require("expo-notifications"); } catch { Notifications = null; }
try { Device = require("expo-device"); } catch { Device = null; }
try { Application = require("expo-application"); } catch { Application = null; }
try { Constants = require("expo-constants"); } catch { Constants = null; }
try { Crypto = require("expo-crypto"); } catch { Crypto = null; }
try { Localization = require("expo-localization"); } catch { Localization = null; }
/* eslint-enable @typescript-eslint/no-require-imports */

export function createExpoPlatform(opts: ExpoPlatformOptions = {}): PlatformAdapter {

  const AsyncStorage: KeyValueStorage | null = AsyncStorageMod?.default ?? AsyncStorageMod ?? null;
  if (!AsyncStorage || typeof AsyncStorage.getItem !== "function") {
    throw new Error("@krontelli/sdk-react-native needs @react-native-async-storage/async-storage; install it and rebuild the app");
  }

  const os = RN?.Platform?.OS ?? "web";
  const platform: Platform = os === "ios" ? "ios" : os === "android" ? "android" : "web";
  const isDev = typeof __DEV__ === "boolean" ? __DEV__ : false;
  const expoConfig = Constants?.default?.expoConfig ?? Constants?.expoConfig ?? null;

  const deviceInfo = (): DeviceInfo => {
    const info: DeviceInfo = {};
    const osVersion = Device?.osVersion ?? (RN?.Platform?.Version !== undefined ? String(RN.Platform.Version) : undefined);
    if (osVersion) info.os_version = String(osVersion);
    const appVersion = opts.appVersion ?? Application?.nativeApplicationVersion ?? expoConfig?.version;
    if (appVersion) info.app_version = String(appVersion);
    const tz = detectTimezone(Localization);
    if (tz) info.timezone = tz;
    const locale = detectLocale(RN, Localization);
    if (locale) info.locale = locale;
    return info;
  };

  return {
    platform,
    isDev,
    secureStorage: createSecureStorage(SecureStore),
    storage: AsyncStorage,
    fetch: (...args) => fetch(...args),
    randomUUID: randomUUIDFactory(Crypto),
    now: () => Date.now(),
    deviceInfo,
    appState: createAppState(RN),
    notifications: Notifications ? createNotificationsAdapter(Notifications) : null,
    apnsEnvironmentHint(): PushEnvironment | null {
      // The signed entitlement is decided by the provisioning profile at build time and is not
      // readable from JS without a native module. When the app declares it in app.json
      // (ios.entitlements["aps-environment"]) we trust that; otherwise the caller falls back to
      // __DEV__. Verify on a real build: TestFlight / App Store / ad-hoc are "production".
      const ent = expoConfig?.ios?.entitlements?.["aps-environment"];
      if (ent === "development") return "sandbox";
      if (ent === "production") return "production";
      return null;
    },
  };
}
