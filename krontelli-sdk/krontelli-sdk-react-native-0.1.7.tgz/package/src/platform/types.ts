/**
 * Platform adapter: everything the SDK needs from the host runtime, behind an interface so the
 * pure logic (queue, HTTP client, payload parsing, credential storage) can be unit-tested without
 * importing any Expo module. `platform/expo.ts` is the production implementation and
 * `platform/memory.ts` the test one.
 */
import type { OsPermission, Platform, PushEnvironment } from "../types";

export interface KeyValueStorage {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

export type AppStateStatus = "active" | "background" | "inactive" | "unknown" | "extension";

export interface AppStateAdapter {
  current(): AppStateStatus;
  /** Returns an unsubscribe function. */
  subscribe(listener: (state: AppStateStatus) => void): () => void;
}

export interface DevicePushToken {
  /** "ios" | "android" | "web" as reported by expo-notifications. */
  type: string;
  /** Hex APNs token on iOS, FCM registration token on Android. */
  data: unknown;
}

export interface NotificationsAdapter {
  getPermission(): Promise<OsPermission>;
  requestPermission(): Promise<OsPermission>;
  getDevicePushToken(): Promise<DevicePushToken>;
  addPushTokenListener(listener: (token: DevicePushToken) => void): () => void;
  /** Fires while the app is foregrounded and a notification arrives. */
  addNotificationReceivedListener(listener: (notification: unknown) => void): () => void;
  /** Fires when the user taps a notification (app foreground, background or cold start). */
  addNotificationResponseReceivedListener(listener: (response: unknown) => void): () => void;
  /** The response that launched the app, if any (cold start). */
  getLastNotificationResponse(): Promise<unknown | null>;
}

export interface DeviceInfo {
  os_version?: string;
  app_version?: string;
  timezone?: string;
  locale?: string;
}

export interface PlatformAdapter {
  platform: Platform;
  isDev: boolean;
  /** Keychain / Keystore backed storage, or null when expo-secure-store is unavailable. */
  secureStorage: KeyValueStorage | null;
  /** AsyncStorage (event queue, flags, credential fallback). */
  storage: KeyValueStorage;
  fetch: typeof fetch;
  randomUUID(): string;
  now(): number;
  deviceInfo(): DeviceInfo;
  appState: AppStateAdapter;
  /** null when expo-notifications is not installed (events-only usage). */
  notifications: NotificationsAdapter | null;
  /**
   * Best-effort APNs environment from build metadata (the `aps-environment` entitlement declared in
   * the Expo config). null when unknown; the SDK then falls back to isDev ? sandbox : production.
   */
  apnsEnvironmentHint(): PushEnvironment | null;
  /** Optional wait primitive used between HTTP retries; defaults to setTimeout. Tests make it instant. */
  sleep?(ms: number): Promise<void>;
}
