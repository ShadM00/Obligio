/**
 * In-memory platform adapter for tests and for running the SDK's pure logic outside a device.
 * Everything is observable and controllable from the outside.
 */
import type { OsPermission, PushEnvironment } from "../types";
import type {
  AppStateAdapter,
  AppStateStatus,
  DeviceInfo,
  DevicePushToken,
  KeyValueStorage,
  NotificationsAdapter,
  PlatformAdapter,
} from "./types";

export class MemoryStorage implements KeyValueStorage {
  readonly map = new Map<string, string>();
  /** Set to make the next write fail (simulates a full disk or a Keychain error). */
  failNextWrite = false;
  writes = 0;
  async getItem(key: string): Promise<string | null> {
    return this.map.has(key) ? (this.map.get(key) as string) : null;
  }
  async setItem(key: string, value: string): Promise<void> {
    if (this.failNextWrite) {
      this.failNextWrite = false;
      throw new Error("storage write failed");
    }
    this.writes += 1;
    this.map.set(key, value);
  }
  async removeItem(key: string): Promise<void> {
    this.map.delete(key);
  }
}

export class MemoryAppState implements AppStateAdapter {
  private state: AppStateStatus = "active";
  private listeners = new Set<(s: AppStateStatus) => void>();
  current(): AppStateStatus {
    return this.state;
  }
  subscribe(listener: (state: AppStateStatus) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  set(state: AppStateStatus): void {
    this.state = state;
    for (const l of Array.from(this.listeners)) l(state);
  }
}

export class MemoryNotifications implements NotificationsAdapter {
  permission: OsPermission = "undetermined";
  permissionOnRequest: OsPermission = "granted";
  token: DevicePushToken = { type: "ios", data: "a".repeat(64) };
  lastResponse: unknown | null = null;
  private tokenListeners = new Set<(t: DevicePushToken) => void>();
  private receivedListeners = new Set<(n: unknown) => void>();
  private responseListeners = new Set<(r: unknown) => void>();

  async getPermission(): Promise<OsPermission> {
    return this.permission;
  }
  async requestPermission(): Promise<OsPermission> {
    this.permission = this.permissionOnRequest;
    return this.permission;
  }
  async getDevicePushToken(): Promise<DevicePushToken> {
    return this.token;
  }
  addPushTokenListener(listener: (token: DevicePushToken) => void): () => void {
    this.tokenListeners.add(listener);
    return () => this.tokenListeners.delete(listener);
  }
  addNotificationReceivedListener(listener: (notification: unknown) => void): () => void {
    this.receivedListeners.add(listener);
    return () => this.receivedListeners.delete(listener);
  }
  addNotificationResponseReceivedListener(listener: (response: unknown) => void): () => void {
    this.responseListeners.add(listener);
    return () => this.responseListeners.delete(listener);
  }
  async getLastNotificationResponse(): Promise<unknown | null> {
    return this.lastResponse;
  }

  // Test controls
  emitToken(token: DevicePushToken): void {
    this.token = token;
    for (const l of Array.from(this.tokenListeners)) l(token);
  }
  emitReceived(notification: unknown): void {
    for (const l of Array.from(this.receivedListeners)) l(notification);
  }
  emitResponse(response: unknown): void {
    for (const l of Array.from(this.responseListeners)) l(response);
  }
}

export interface MemoryPlatformOptions {
  platform?: "ios" | "android" | "web";
  isDev?: boolean;
  secureStorage?: KeyValueStorage | null;
  storage?: KeyValueStorage;
  fetch?: typeof fetch;
  now?: () => number;
  deviceInfo?: DeviceInfo;
  notifications?: NotificationsAdapter | null;
  apnsEnvironmentHint?: PushEnvironment | null;
}

let uuidCounter = 0;
/** Deterministic RFC-4122-shaped ids for tests. */
export function fakeUUID(): string {
  uuidCounter += 1;
  const hex = uuidCounter.toString(16).padStart(12, "0");
  return `00000000-0000-4000-8000-${hex}`;
}

export class MemoryPlatform implements PlatformAdapter {
  platform: "ios" | "android" | "web";
  isDev: boolean;
  secureStorage: KeyValueStorage | null;
  storage: KeyValueStorage;
  fetch: typeof fetch;
  appState = new MemoryAppState();
  notifications: NotificationsAdapter | null;
  private readonly nowFn: () => number;
  private readonly info: DeviceInfo;
  private readonly hint: PushEnvironment | null;

  constructor(opts: MemoryPlatformOptions = {}) {
    this.platform = opts.platform ?? "ios";
    this.isDev = opts.isDev ?? true;
    this.secureStorage = opts.secureStorage === undefined ? new MemoryStorage() : opts.secureStorage;
    this.storage = opts.storage ?? new MemoryStorage();
    this.fetch = opts.fetch ?? (() => Promise.reject(new Error("no fetch configured")));
    this.nowFn = opts.now ?? (() => Date.now());
    this.info = opts.deviceInfo ?? { os_version: "17.0", app_version: "1.0.0", timezone: "Australia/Sydney", locale: "en-AU" };
    this.notifications = opts.notifications === undefined ? new MemoryNotifications() : opts.notifications;
    this.hint = opts.apnsEnvironmentHint ?? null;
  }
  randomUUID(): string {
    return fakeUUID();
  }
  now(): number {
    return this.nowFn();
  }
  deviceInfo(): DeviceInfo {
    return { ...this.info };
  }
  apnsEnvironmentHint(): PushEnvironment | null {
    return this.hint;
  }
  /** Instant: tests must never wait on real backoff timers. */
  sleep(): Promise<void> {
    return Promise.resolve();
  }
}
