/**
 * Public types for the Krontelli React Native / Expo SDK.
 * The wire shapes mirror packages/shared/openapi.json (the "sdk" tag) and must not drift from it.
 */
import type { PlatformAdapter } from "./platform/types";

export type Platform = "ios" | "android" | "web";
export type PushProvider = "apns" | "fcm";
export type PushEnvironment = "sandbox" | "production";
export type OsPermission = "undetermined" | "granted" | "provisional" | "denied";

export type EventProps = Record<string, unknown>;

/** Minimal surface of `@sentry/react-native` used by the diagnostics bridge. */
export interface SentryLike {
  setUser(user: { id?: string; [key: string]: unknown } | null): void;
}

export interface KrontelliLogger {
  debug(...args: unknown[]): void;
  info(...args: unknown[]): void;
  warn(...args: unknown[]): void;
  error(...args: unknown[]): void;
}

export interface InitOptions {
  /** e.g. "https://api.krontelli.com" — compiled into the app, never changes once shipped. */
  apiBaseUrl: string;
  /** Public app key "kt_pub_…". It can only create installations. */
  publicKey: string;
  /** Overrides the version read from expo-application / expo-constants. */
  appVersion?: string;
  /**
   * APNs environment override. Default: the `aps-environment` entitlement declared in the Expo
   * config when present, else `__DEV__ ? "sandbox" : "production"`.
   */
  apnsEnvironment?: PushEnvironment;
  /**
   * Collect nothing until the app calls setConsentGiven(true) (OneSignal's setConsentRequired). Until then the
   * SDK does not register the device, sends no events (track() and screen() are dropped, not queued) and reports
   * no push token; requestPermission() still shows the OS dialog. The choice is stored, so later launches start
   * normally. Default false.
   */
  consentRequired?: boolean;
  /** Ask for OS notification permission during init. Default false: call requestPermission() yourself. */
  requestPermissionOnInit?: boolean;
  /** Rotate the installation credential when it is older than this many days. 0 disables. Default 30. */
  credentialRotationDays?: number;
  /** Optional `@sentry/react-native` module (or anything with setUser). No hard dependency. */
  sentry?: SentryLike;
  /** Optional logger; defaults to console with a "[krontelli]" prefix, debug only in __DEV__. */
  logger?: Partial<KrontelliLogger>;
  /** Request timeout in milliseconds. Default 15000. */
  requestTimeoutMs?: number;
  /** Events module tuning; defaults match the design doc (10 s / 20 events / batches of 100). */
  events?: {
    /**
     * Send the automatic events (first_open, app_open, app_update, session_start, push_received,
     * push_opened). Default true. False makes the SDK push-only: nothing reaches /v1/events unless the
     * app calls track() or screen() itself. Delivery receipts are still sent, so message stats keep working.
     */
    automatic?: boolean;
    flushIntervalMs?: number;
    flushAtCount?: number;
    maxEventAgeMs?: number;
    maxQueueLength?: number;
  };
  /** Inject a platform adapter (tests, bare React Native). Defaults to the Expo adapter. */
  platform?: PlatformAdapter;
}

export interface NotificationOpenedEvent {
  deliveryId: string | null;
  deepLink: string | null;
  imageUrl: string | null;
  /** The full `data` map of the notification as delivered by expo-notifications. */
  data: Record<string, unknown>;
  /** The raw expo-notifications response object. */
  raw: unknown;
}

export type NotificationOpenedCallback = (event: NotificationOpenedEvent) => void;

export interface KrontelliErrorInfo {
  status?: number;
  code?: string;
  retryAfterMs?: number;
}

export class KrontelliError extends Error {
  readonly status: number | undefined;
  readonly code: string | undefined;
  readonly retryAfterMs: number | undefined;
  constructor(message: string, info: KrontelliErrorInfo = {}) {
    super(message);
    this.name = "KrontelliError";
    this.status = info.status;
    this.code = info.code;
    this.retryAfterMs = info.retryAfterMs;
  }
}
