/** Reported as `sdk_version` on every installation. Keep in sync with package.json. */
export const SDK_VERSION = "0.1.7";
export const SDK_NAME = "@krontelli/sdk-react-native";
