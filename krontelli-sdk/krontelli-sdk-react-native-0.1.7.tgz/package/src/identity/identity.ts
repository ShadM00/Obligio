/**
 * Identity: link/unlink the installation to a person and record consent.
 * The identity token is a JWT minted by the app's own backend (HS256, `kid` header, aud = app id,
 * ≤ 5 min expiry, jti). The SDK forwards it verbatim and never inspects the signature.
 */
import { HttpError } from "../core/http";
import type { InstallationManager } from "../core/installation";
import { KrontelliError, type KrontelliLogger } from "../types";

export interface LoginResult {
  person_id: string;
  external_id: string;
}

export interface IdentityEvents {
  onLogin?: (result: LoginResult) => void;
  onLogout?: () => void;
}

export class IdentityModule {
  private readonly installation: InstallationManager;
  private readonly log: KrontelliLogger;
  private readonly events: IdentityEvents;
  private current: LoginResult | null = null;

  constructor(installation: InstallationManager, log: KrontelliLogger, events: IdentityEvents = {}) {
    this.installation = installation;
    this.log = log;
    this.events = events;
  }

  get person(): LoginResult | null {
    return this.current;
  }

  async login(identityToken: string): Promise<LoginResult> {
    if (typeof identityToken !== "string" || identityToken.split(".").length !== 3) {
      throw new KrontelliError("login(): identityToken must be a compact JWT minted by your backend", { code: "bad_identity_token" });
    }
    try {
      const result = await this.installation.authorized<LoginResult>("POST", "/v1/installations/me/login", {
        body: { identity_token: identityToken },
        isLogin: true,
        retries: 1,
      });
      this.current = result;
      this.events.onLogin?.(result);
      return result;
    } catch (err) {
      throw toKrontelliError(err, "login failed");
    }
  }

  async logout(): Promise<void> {
    try {
      await this.installation.authorized("POST", "/v1/installations/me/logout", { retries: 1 });
    } catch (err) {
      throw toKrontelliError(err, "logout failed");
    } finally {
      this.current = null;
      this.events.onLogout?.();
    }
  }

  async setMarketingConsent(consent: boolean): Promise<void> {
    try {
      await this.installation.authorized("PUT", "/v1/installations/me/consent", { body: { marketing_consent: Boolean(consent) }, retries: 2 });
    } catch (err) {
      throw toKrontelliError(err, "setMarketingConsent failed");
    }
  }

  /** The installation was replaced (re-enrolled): the person link is gone until the next login(). */
  onReenrolled(): void {
    if (this.current) this.log.warn("installation re-enrolled; call login() again to re-link the user");
    this.current = null;
    this.events.onLogout?.();
  }
}

export function toKrontelliError(err: unknown, fallback: string): KrontelliError {
  if (err instanceof KrontelliError) return err;
  if (err instanceof HttpError) return new KrontelliError(err.message || fallback, { status: err.status, code: err.code, retryAfterMs: err.retryAfterMs });
  if (err instanceof Error) return new KrontelliError(err.message || fallback);
  return new KrontelliError(fallback);
}
