/**
 * @krontelli/sdk-react-native — public API.
 *
 * Every function is safe to call before init() resolves: track()/screen()/onNotificationOpened()
 * are buffered in memory and replayed; the async functions wait for the client to be ready.
 */
import { KrontelliClient } from "./client";
import { createExpoPlatform } from "./platform/expo";
import type { PlatformAdapter } from "./platform/types";
import type { EventProps, InitOptions, NotificationOpenedCallback, OsPermission } from "./types";

export * from "./types";
export type { PlatformAdapter, KeyValueStorage, NotificationsAdapter, AppStateAdapter, DevicePushToken } from "./platform/types";
export type { KtPayload } from "./push/payload";
export type { LoginResult } from "./identity/identity";
export { KrontelliClient } from "./client";
export { extractKt, parseKtFromData, parseKtBlock } from "./push/payload";
export { MemoryPlatform, MemoryStorage, MemoryNotifications } from "./platform/memory";
export { SDK_VERSION } from "./version";

let client: KrontelliClient | null = null;
let resolveClient: ((c: KrontelliClient) => void) | null = null;
let clientPromise: Promise<KrontelliClient> = new Promise((resolve) => {
  resolveClient = resolve;
});

type Buffered = { kind: "track"; name: string; props?: EventProps } | { kind: "screen"; name: string; props?: EventProps };
const buffered: Buffered[] = [];
const pendingOpenedCallbacks = new Map<NotificationOpenedCallback, { unsubscribe: (() => void) | null; removed: boolean }>();

function whenReady(): Promise<KrontelliClient> {
  if (client) return client.ready().then(() => client as KrontelliClient);
  return clientPromise.then((c) => c.ready().then(() => c));
}

/**
 * Initialise the SDK. Call once, as early as possible (module scope or the root component).
 * Resolves when the installation is registered (or registration has been deferred because the
 * device is offline) and the push/event modules are running.
 */
export async function init(options: InitOptions): Promise<KrontelliClient> {
  if (client) {
    client.log.warn("Krontelli.init() called twice; ignoring the second call");
    return client;
  }
  const platform: PlatformAdapter = options.platform ?? createExpoPlatform();
  client = new KrontelliClient(options, platform);
  // Replay anything buffered before init(). track() must be sync, so these go in before ready().
  for (const b of buffered.splice(0)) {
    if (b.kind === "track") client.track(b.name, b.props);
    else client.screen(b.name, b.props);
  }
  for (const [cb, entry] of pendingOpenedCallbacks) {
    if (!entry.removed) entry.unsubscribe = client.onNotificationOpened(cb);
  }
  resolveClient?.(client);
  await client.ready();
  return client;
}

/** Queue a custom event. Synchronous; persisted and sent in the background. */
export function track(name: string, props?: EventProps): void {
  if (client) client.track(name, props);
  else buffered.push({ kind: "track", name, props });
}

/** Queue a screen_view event. */
export function screen(name: string, props?: EventProps): void {
  if (client) client.screen(name, props);
  else buffered.push({ kind: "screen", name, props });
}

/** Link this installation to the user named by an identity token minted by your backend. */
export async function login(identityToken: string) {
  return (await whenReady()).login(identityToken);
}

/** Unlink immediately; the installation becomes anonymous and marketing consent reverts to false. */
export async function logout(): Promise<void> {
  return (await whenReady()).logout();
}

/** Ask the OS for notification permission and report the result + token. */
export async function requestPermission(): Promise<OsPermission> {
  return (await whenReady()).requestPermission();
}

/** Answer for init({ consentRequired: true }): true starts collection, false stops it. Stored across launches. */
export async function setConsentGiven(given: boolean): Promise<void> {
  return (await whenReady()).setConsentGiven(given);
}

/** In-app marketing opt-in/out, separate from the OS permission. */
export async function setPushOptIn(optIn: boolean): Promise<void> {
  return (await whenReady()).setPushOptIn(optIn);
}

/** Marketing consent: recorded against the person when linked, else the installation. */
export async function setMarketingConsent(consent: boolean): Promise<void> {
  return (await whenReady()).setMarketingConsent(consent);
}

/**
 * Called when the user opens a notification (also for the one that cold-started the app).
 * Receives { deliveryId, deepLink, imageUrl, data, raw }. Returns an unsubscribe function.
 */
export function onNotificationOpened(cb: NotificationOpenedCallback): () => void {
  if (client) return client.onNotificationOpened(cb);
  const entry = { unsubscribe: null as (() => void) | null, removed: false };
  pendingOpenedCallbacks.set(cb, entry);
  return () => {
    entry.removed = true;
    entry.unsubscribe?.();
    pendingOpenedCallbacks.delete(cb);
  };
}

/** The installation id, or null before registration has completed. */
export function getInstallationId(): string | null {
  return client?.getInstallationId() ?? null;
}

/** Send every queued event now (e.g. before the app is killed). */
export async function flush(): Promise<void> {
  return (await whenReady()).flush();
}

/** Force a credential rotation (the SDK also rotates automatically every `credentialRotationDays`). */
export async function rotateCredential(): Promise<void> {
  return (await whenReady()).rotateCredential();
}

/** @internal Tests only: forget the singleton so init() can run again. */
export function _resetForTests(): void {
  client?.destroy();
  client = null;
  buffered.length = 0;
  pendingOpenedCallbacks.clear();
  clientPromise = new Promise((resolve) => {
    resolveClient = resolve;
  });
}

const Krontelli = {
  init,
  login,
  logout,
  track,
  screen,
  requestPermission,
  setPushOptIn,
  setConsentGiven,
  setMarketingConsent,
  onNotificationOpened,
  getInstallationId,
  flush,
  rotateCredential,
};

export default Krontelli;
