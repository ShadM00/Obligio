/**
 * Reads the Krontelli block out of a push payload.
 *
 * iOS (APNs payload root, as the Notification Service Extension and expo-notifications see it):
 *   { aps: {...}, kt: { d: "<delivery_id>", r: "<receipt_token>" }, deep_link?: "…", image_url?: "…" }
 * Android (FCM notification message; the data map only holds strings):
 *   data: { kt: '{"d":"…","r":"…"}', deep_link?: "…" }
 *
 * expo-notifications surfaces these as `notification.request.content.data` on both platforms, but
 * we also look in `request.trigger.payload` (iOS full payload) and `request.trigger.remoteMessage.data`
 * (Android) because the mapping differs between SDK versions.
 */
export interface KtPayload {
  deliveryId: string;
  receiptToken: string;
  deepLink: string | null;
  imageUrl: string | null;
}

type Dict = Record<string, unknown>;

function isDict(v: unknown): v is Dict {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function str(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

/** Parses the `kt` value whether it arrived as an object (iOS) or a JSON string (Android). */
export function parseKtBlock(kt: unknown): { d: string; r: string } | null {
  let obj: unknown = kt;
  if (typeof kt === "string") {
    try {
      obj = JSON.parse(kt);
    } catch {
      return null;
    }
  }
  if (!isDict(obj)) return null;
  const d = str(obj.d) ?? str(obj.delivery_id);
  const r = str(obj.r) ?? str(obj.receipt_token);
  if (!d || !r) return null;
  return { d, r };
}

/** Parses a data map (iOS payload root or Android data map). */
export function parseKtFromData(data: unknown): KtPayload | null {
  if (!isDict(data)) return null;
  const block = parseKtBlock(data.kt);
  if (!block) return null;
  return {
    deliveryId: block.d,
    receiptToken: block.r,
    deepLink: str(data.deep_link),
    imageUrl: str(data.image_url),
  };
}

/** Candidate data maps inside an expo-notifications `Notification` object, most specific first. */
export function candidateDataMaps(notification: unknown): Dict[] {
  const out: Dict[] = [];
  if (!isDict(notification)) return out;
  const request = isDict(notification.request) ? notification.request : null;
  const content = request && isDict(request.content) ? request.content : null;
  const trigger = request && isDict(request.trigger) ? request.trigger : null;
  if (content && isDict(content.data)) out.push(content.data);
  // Some expo-notifications versions wrap Android data under `body` (string or object).
  if (content && isDict(content.data) && content.data.body !== undefined) {
    const body = content.data.body;
    if (isDict(body)) out.push(body);
    else if (typeof body === "string") {
      try {
        const parsed = JSON.parse(body) as unknown;
        if (isDict(parsed)) out.push(parsed);
      } catch {
        /* not JSON */
      }
    }
  }
  if (trigger && isDict(trigger.payload)) out.push(trigger.payload);
  if (trigger && isDict(trigger.remoteMessage) && isDict(trigger.remoteMessage.data)) out.push(trigger.remoteMessage.data);
  // Accept a bare data map or a bare APNs payload too (but not a Notification wrapper itself).
  if (!request) out.push(notification);
  return out;
}

/** Extracts the Krontelli block from an expo-notifications Notification (or a raw payload). */
export function extractKt(notification: unknown): KtPayload | null {
  for (const data of candidateDataMaps(notification)) {
    const parsed = parseKtFromData(data);
    if (parsed) return parsed;
  }
  return null;
}

/** The data map to hand the app (first candidate with any keys), or {}. */
export function extractData(notification: unknown): Dict {
  for (const data of candidateDataMaps(notification)) {
    if (Object.keys(data).length > 0) return data;
  }
  return {};
}

/** Deep link without a kt block (e.g. a push sent by another provider during migration). */
export function extractDeepLink(notification: unknown): string | null {
  for (const data of candidateDataMaps(notification)) {
    const link = str(data.deep_link) ?? str(data.deepLink) ?? str(data.url);
    if (link) return link;
  }
  return null;
}

/** expo-notifications `NotificationResponse` → its Notification. Accepts a bare Notification as well. */
export function notificationFromResponse(response: unknown): unknown {
  if (isDict(response) && isDict(response.notification)) return response.notification;
  return response;
}
