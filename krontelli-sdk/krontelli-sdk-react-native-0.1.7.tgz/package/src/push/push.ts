/**
 * Push module: native device token (APNs / FCM, bypassing Expo's push service), OS permission,
 * subscription reporting, receipts and notification-open handling.
 */
import type { HttpClient } from "../core/http";
import type { InstallationManager } from "../core/installation";
import type { DevicePushToken, PlatformAdapter } from "../platform/types";
import type { KrontelliLogger, NotificationOpenedCallback, NotificationOpenedEvent, OsPermission, PushEnvironment, PushProvider } from "../types";
import { extractData, extractDeepLink, extractKt, notificationFromResponse } from "./payload";

export const LAST_OPENED_KEY = "krontelli.push.last_opened.v1";
export const PUSH_OPT_IN_KEY = "krontelli.push.opt_in.v1";
/** The permission last accepted by the server, so a change made while the app was not running is still reported. */
export const REPORTED_PERMISSION_KEY = "krontelli.push.reported_permission.v1";

export interface SubscriptionBody {
  provider: PushProvider;
  environment?: PushEnvironment;
  token: string;
  os_permission?: OsPermission;
  push_opt_in?: boolean;
}

export interface PushManagerOptions {
  platform: PlatformAdapter;
  http: HttpClient;
  installation: InstallationManager;
  log: KrontelliLogger;
  track: (name: string, props?: Record<string, unknown>) => void;
  apnsEnvironment?: PushEnvironment;
  requestPermissionOnInit?: boolean;
}

/** Resolve the APNs environment: explicit override → build hint → __DEV__ heuristic. */
export function resolveApnsEnvironment(platform: PlatformAdapter, override: PushEnvironment | undefined): PushEnvironment {
  if (override) return override;
  const hint = platform.apnsEnvironmentHint();
  if (hint) return hint;
  return platform.isDev ? "sandbox" : "production";
}

export function tokenToString(token: DevicePushToken): string | null {
  const data = token.data;
  if (typeof data === "string") return data;
  if (data && typeof data === "object") {
    // Web push tokens are objects; not supported by this SDK but don't crash.
    try {
      return JSON.stringify(data);
    } catch {
      return null;
    }
  }
  return null;
}

export function providerForToken(token: DevicePushToken, platform: PlatformAdapter): PushProvider | null {
  if (token.type === "ios") return "apns";
  if (token.type === "android") return "fcm";
  if (platform.platform === "ios") return "apns";
  if (platform.platform === "android") return "fcm";
  return null;
}

export class PushManager {
  private readonly platform: PlatformAdapter;
  private readonly http: HttpClient;
  private readonly installation: InstallationManager;
  private readonly log: KrontelliLogger;
  private readonly track: (name: string, props?: Record<string, unknown>) => void;
  private readonly apnsOverride: PushEnvironment | undefined;
  private readonly requestOnInit: boolean;
  private readonly openedCallbacks = new Set<NotificationOpenedCallback>();
  private pendingOpened: NotificationOpenedEvent | null = null;
  private unsubscribers: Array<() => void> = [];
  private lastToken: DevicePushToken | null = null;
  private lastPermission: OsPermission = "undetermined";
  private pushOptIn: boolean | undefined;
  private started = false;
  private lastOpenedId: string | null | undefined;
  private lastSentSubscription: string | null = null;

  constructor(opts: PushManagerOptions) {
    this.platform = opts.platform;
    this.http = opts.http;
    this.installation = opts.installation;
    this.log = opts.log;
    this.track = opts.track;
    this.apnsOverride = opts.apnsEnvironment;
    this.requestOnInit = opts.requestPermissionOnInit ?? false;
  }

  get permission(): OsPermission {
    return this.lastPermission;
  }

  get environment(): PushEnvironment {
    return resolveApnsEnvironment(this.platform, this.apnsOverride);
  }

  /** Wires listeners, reads permission state and reports the current token. Never throws. */
  async start(): Promise<void> {
    if (this.started) return;
    this.started = true;
    const n = this.platform.notifications;
    const stored = await this.platform.storage.getItem(PUSH_OPT_IN_KEY).catch(() => null);
    if (stored === "true" || stored === "false") this.pushOptIn = stored === "true";
    if (!n) {
      this.log.info("expo-notifications not available; push disabled");
      return;
    }
    this.unsubscribers.push(
      n.addPushTokenListener((token) => {
        void this.reportToken(token).catch((err) => this.log.warn("token refresh report failed", err));
      }),
      n.addNotificationReceivedListener((notification) => {
        void this.handleReceived(notification);
      }),
      n.addNotificationResponseReceivedListener((response) => {
        void this.handleOpened(response);
      }),
      // Permission can change in system Settings while the app is away; re-check on every return.
      this.platform.appState.subscribe((state) => {
        if (state === "active") void this.syncPermission().catch((err) => this.log.warn("permission sync failed", err));
      }),
    );
    try {
      this.lastPermission = await n.getPermission();
    } catch (err) {
      this.log.warn("getPermission failed", err);
    }
    if (this.requestOnInit && this.lastPermission === "undetermined") {
      await this.requestPermission().catch((err) => this.log.warn("requestPermission failed", err));
    } else if (this.lastPermission === "granted" || this.lastPermission === "provisional") {
      await this.refreshToken().catch((err) => this.log.warn("initial token report failed", err));
    } else {
      // Android kills the app when notifications are turned off in Settings, so the change is only
      // seen here, at the next start. Report it, or the server keeps sending to a device that drops them.
      const reported = await this.platform.storage.getItem(REPORTED_PERMISSION_KEY).catch(() => null);
      if (reported && reported !== this.lastPermission) {
        await this.refreshToken().catch((err) => this.log.warn("permission change report failed", err));
      }
    }
    // Cold start from a notification tap.
    try {
      const last = await n.getLastNotificationResponse();
      if (last) await this.handleOpened(last);
    } catch (err) {
      this.log.warn("getLastNotificationResponse failed", err);
    }
  }

  stop(): void {
    for (const u of this.unsubscribers) u();
    this.unsubscribers = [];
    this.started = false;
  }

  /** Ask the OS for permission, then report permission + token. */
  async requestPermission(): Promise<OsPermission> {
    const n = this.platform.notifications;
    if (!n) return "undetermined";
    this.lastPermission = await n.requestPermission();
    if (this.lastPermission === "granted" || this.lastPermission === "provisional") {
      await this.refreshToken();
    } else if (this.lastToken) {
      // Permission revoked after a token existed: report the new state with the known token.
      await this.reportToken(this.lastToken);
    }
    return this.lastPermission;
  }

  /** Re-read the OS permission without prompting; report it when it changed since the last check. */
  async syncPermission(): Promise<OsPermission> {
    const n = this.platform.notifications;
    if (!n) return "undetermined";
    const previous = this.lastPermission;
    this.lastPermission = await n.getPermission();
    if (this.lastPermission === previous) return previous;
    if (this.lastPermission === "granted" || this.lastPermission === "provisional") await this.refreshToken();
    else if (this.lastToken) await this.reportToken(this.lastToken);
    return this.lastPermission;
  }

  /** Persist the opt-in flag and report it with the current token (or when the token arrives). */
  async setPushOptIn(optIn: boolean): Promise<void> {
    this.pushOptIn = optIn;
    await this.platform.storage.setItem(PUSH_OPT_IN_KEY, String(optIn)).catch(() => undefined);
    if (this.lastToken) await this.reportToken(this.lastToken, true);
    else this.log.debug("push opt-in stored; will be sent with the first token");
  }

  /** Fetch the native token and report it. */
  async refreshToken(): Promise<void> {
    const n = this.platform.notifications;
    if (!n) return;
    const token = await n.getDevicePushToken();
    await this.reportToken(token);
  }

  /** After re-enrolment the new installation has no subscription: resend. */
  async resendSubscription(): Promise<void> {
    this.lastSentSubscription = null;
    if (this.lastToken) await this.reportToken(this.lastToken, true);
  }

  private async reportToken(token: DevicePushToken, force = false): Promise<void> {
    this.lastToken = token;
    const value = tokenToString(token);
    const provider = providerForToken(token, this.platform);
    if (!value || !provider) {
      this.log.warn("unsupported push token", token.type);
      return;
    }
    const body: SubscriptionBody = { provider, token: value, os_permission: this.lastPermission };
    if (provider === "apns") body.environment = this.environment;
    if (this.pushOptIn !== undefined) body.push_opt_in = this.pushOptIn;
    const serialized = JSON.stringify(body);
    if (!force && serialized === this.lastSentSubscription) return;
    await this.installation.authorized("PUT", "/v1/installations/me/subscription", { body, retries: 2 });
    this.lastSentSubscription = serialized;
    await this.platform.storage.setItem(REPORTED_PERMISSION_KEY, this.lastPermission).catch(() => undefined);
    this.log.debug("subscription reported", provider, body.environment ?? "");
  }

  /** POST /v1/receipts with the per-delivery receipt token. Best effort; the server is idempotent. */
  async sendReceipt(deliveryId: string, token: string, kind: "received" | "opened"): Promise<void> {
    try {
      await this.http.request("POST", "/v1/receipts", {
        body: { delivery_id: deliveryId, kind, token, at: new Date(this.platform.now()).toISOString() },
        auth: token,
        retries: 2,
      });
    } catch (err) {
      this.log.warn(`receipt ${kind} for ${deliveryId} failed`, err);
    }
  }

  /** Foreground arrival: the app is open, so we record `received` here (the NSE does it in the background on iOS). */
  async handleReceived(notification: unknown): Promise<void> {
    const kt = extractKt(notification);
    if (!kt) return;
    this.track("push_received", { delivery_id: kt.deliveryId, foreground: true });
    await this.sendReceipt(kt.deliveryId, kt.receiptToken, "received");
  }

  /** Notification tap (foreground, background or cold start). */
  async handleOpened(response: unknown): Promise<void> {
    const notification = notificationFromResponse(response);
    const kt = extractKt(notification);
    const data = extractData(notification);
    const deepLink = kt?.deepLink ?? extractDeepLink(notification);
    if (kt) {
      if (await this.alreadyOpened(kt.deliveryId)) return;
      await this.rememberOpened(kt.deliveryId);
      this.track("push_opened", { delivery_id: kt.deliveryId, ...(deepLink ? { deep_link: deepLink } : {}) });
      void this.sendReceipt(kt.deliveryId, kt.receiptToken, "opened");
    }
    const event: NotificationOpenedEvent = {
      deliveryId: kt?.deliveryId ?? null,
      deepLink,
      imageUrl: kt?.imageUrl ?? null,
      data,
      raw: response,
    };
    this.emitOpened(event);
  }

  /** Register a handler. If a notification opened the app before the handler existed, it is delivered immediately. */
  onNotificationOpened(cb: NotificationOpenedCallback): () => void {
    this.openedCallbacks.add(cb);
    if (this.pendingOpened) {
      const pending = this.pendingOpened;
      this.pendingOpened = null;
      safeCall(cb, pending, this.log);
    }
    return () => this.openedCallbacks.delete(cb);
  }

  private emitOpened(event: NotificationOpenedEvent): void {
    if (this.openedCallbacks.size === 0) {
      this.pendingOpened = event;
      return;
    }
    for (const cb of Array.from(this.openedCallbacks)) safeCall(cb, event, this.log);
  }

  /** getLastNotificationResponseAsync can replay the launch response after a JS reload; dedupe by delivery id. */
  private async alreadyOpened(deliveryId: string): Promise<boolean> {
    if (this.lastOpenedId === undefined) {
      this.lastOpenedId = await this.platform.storage.getItem(LAST_OPENED_KEY).catch(() => null);
    }
    return this.lastOpenedId === deliveryId;
  }

  private async rememberOpened(deliveryId: string): Promise<void> {
    this.lastOpenedId = deliveryId;
    await this.platform.storage.setItem(LAST_OPENED_KEY, deliveryId).catch(() => undefined);
  }
}

function safeCall(cb: NotificationOpenedCallback, event: NotificationOpenedEvent, log: KrontelliLogger): void {
  try {
    cb(event);
  } catch (err) {
    log.error("onNotificationOpened handler threw", err);
  }
}
