/**
 * Wires the five modules together. One instance per app; `index.ts` exposes it as module functions
 * that are safe to call before init() resolves (calls are queued until the client is ready).
 */
import { CredentialStore } from "./core/credentials";
import { HttpClient } from "./core/http";
import { InstallationManager } from "./core/installation";
import { createLogger } from "./core/logger";
import { DiagnosticsBridge } from "./diagnostics/sentry";
import { EventsModule } from "./events/events";
import { IdentityModule, type LoginResult } from "./identity/identity";
import type { PlatformAdapter } from "./platform/types";
import { PUSH_OPT_IN_KEY, PushManager } from "./push/push";
import type { EventProps, InitOptions, KrontelliLogger, NotificationOpenedCallback, OsPermission } from "./types";
import { SDK_NAME, SDK_VERSION } from "./version";

export const CONSENT_KEY = "krontelli.consent.v1";

export class KrontelliClient {
  readonly platform: PlatformAdapter;
  readonly log: KrontelliLogger;
  readonly http: HttpClient;
  readonly credentials: CredentialStore;
  readonly installation: InstallationManager;
  readonly events: EventsModule;
  readonly push: PushManager;
  readonly identity: IdentityModule;
  readonly diagnostics: DiagnosticsBridge;
  private readonly readyPromise: Promise<void>;
  private readyResolved = false;
  private readonly consentRequired: boolean;
  /** True while consentRequired and consent has not been given: nothing leaves the device. */
  private waitingForConsent = false;
  /** consentRequired, before the stored answer has been read: track()/screen() wait here in memory. */
  private undecided: Array<() => void> | null = null;

  constructor(opts: InitOptions, platform: PlatformAdapter) {
    if (!opts || typeof opts.apiBaseUrl !== "string" || !/^https?:\/\//.test(opts.apiBaseUrl)) {
      throw new Error("Krontelli.init(): apiBaseUrl must be an http(s) URL");
    }
    if (typeof opts.publicKey !== "string" || !opts.publicKey.startsWith("kt_pub_")) {
      throw new Error('Krontelli.init(): publicKey must be the app\'s public key ("kt_pub_…")');
    }
    this.platform = platform;
    this.consentRequired = opts.consentRequired ?? false;
    if (this.consentRequired) this.undecided = [];
    this.log = createLogger(opts.logger, platform.isDev);
    this.http = new HttpClient({
      baseUrl: opts.apiBaseUrl,
      fetch: platform.fetch,
      timeoutMs: opts.requestTimeoutMs,
      now: () => platform.now(),
      ...(platform.sleep ? { sleep: (ms: number) => platform.sleep!(ms) } : {}),
      userAgent: `${SDK_NAME}/${SDK_VERSION} ${platform.platform}`,
    });
    this.credentials = new CredentialStore(platform.secureStorage, platform.storage, this.log);
    this.diagnostics = new DiagnosticsBridge(opts.sentry, this.log);
    this.installation = new InstallationManager({
      http: this.http,
      platform,
      publicKey: opts.publicKey,
      credentials: this.credentials,
      log: this.log,
      appVersion: opts.appVersion,
      rotationDays: opts.credentialRotationDays ?? 30,
      events: {
        onRegistered: (installation, reenrolled) => {
          this.diagnostics.setInstallation(installation.installation_id);
          if (reenrolled) {
            this.identity.onReenrolled();
            void this.push.resendSubscription().catch((err) => this.log.warn("subscription resend after re-enrol failed", err));
          }
        },
      },
    });
    this.events = new EventsModule({
      platform,
      installation: this.installation,
      log: this.log,
      appVersion: opts.appVersion,
      ...(opts.events ?? {}),
    });
    this.push = new PushManager({
      platform,
      http: this.http,
      installation: this.installation,
      log: this.log,
      track: (name, props) => {
        if (this.events.automatic) this.events.track(name, props);
      },
      apnsEnvironment: opts.apnsEnvironment,
      requestPermissionOnInit: opts.requestPermissionOnInit,
    });
    this.identity = new IdentityModule(this.installation, this.log, {
      onLogin: (r: LoginResult) => this.diagnostics.setPerson(r),
      onLogout: () => this.diagnostics.clearPerson(),
    });
    this.readyPromise = this.boot();
  }

  /** Resolves once the installation is registered and the modules are started. Never rejects. */
  ready(): Promise<void> {
    return this.readyPromise;
  }

  get isReady(): boolean {
    return this.readyResolved;
  }

  /** False while the app has to call setConsentGiven(true) first (consentRequired). */
  get hasConsent(): boolean {
    return !this.waitingForConsent;
  }

  private async boot(): Promise<void> {
    if (this.consentRequired) {
      const stored = await this.platform.storage.getItem(CONSENT_KEY).catch(() => null);
      const held = this.undecided ?? [];
      this.undecided = null;
      if (stored !== "granted") {
        this.waitingForConsent = true;
        this.readyResolved = true;
        return;
      }
      for (const call of held) call();
    }
    await this.start();
  }

  private async start(): Promise<void> {
    try {
      const cred = await this.installation.ensureRegistered();
      this.diagnostics.setInstallation(cred.installation_id);
    } catch (err) {
      // Offline first launch: keep going. Events queue locally; the next authorized call registers.
      this.log.warn("installation registration failed; will retry on the next request", err);
    }
    await this.events.start();
    await this.push.start();
    this.readyResolved = true;
    // Background housekeeping, after ready so callers are never blocked by it.
    void this.installation
      .syncDeviceInfo()
      .catch((err) => this.log.debug("device info sync skipped", err))
      .then(() => this.installation.maybeRotate());
  }

  /**
   * The user's answer when consentRequired is set. true registers the device and starts events and push.
   * false stops them, drops queued events and, if push was running, reports push_opt_in = false first so the
   * server stops sending; nothing else is sent afterwards. Stored, and applied on later launches.
   */
  async setConsentGiven(given: boolean): Promise<void> {
    await this.readyPromise;
    await this.platform.storage.setItem(CONSENT_KEY, given ? "granted" : "revoked").catch(() => undefined);
    if (given) {
      if (!this.waitingForConsent) return;
      this.waitingForConsent = false;
      await this.start();
      return;
    }
    if (this.waitingForConsent) return;
    await this.push.setPushOptIn(false).catch((err) => this.log.warn("opt-out on consent withdrawal failed", err));
    this.events.stop();
    this.push.stop();
    this.events.queue.ack(this.events.queue.snapshot().map((e) => e.event_id));
    this.waitingForConsent = true;
  }

  track(name: string, props?: EventProps): void {
    if (this.undecided) this.undecided.push(() => this.events.track(name, props));
    else if (!this.waitingForConsent) this.events.track(name, props);
  }

  screen(name: string, props?: EventProps): void {
    if (this.undecided) this.undecided.push(() => this.events.screen(name, props));
    else if (!this.waitingForConsent) this.events.screen(name, props);
  }

  flush(): Promise<void> {
    if (this.waitingForConsent) return Promise.resolve();
    return this.events.flush();
  }

  login(identityToken: string): Promise<LoginResult> {
    if (this.waitingForConsent) return Promise.reject(new Error("Krontelli: login() needs consent first (setConsentGiven(true))"));
    return this.identity.login(identityToken);
  }

  logout(): Promise<void> {
    if (this.waitingForConsent) return Promise.resolve();
    return this.identity.logout();
  }

  setMarketingConsent(consent: boolean): Promise<void> {
    if (this.waitingForConsent) {
      this.log.warn("setMarketingConsent() ignored: no consent to collect data yet");
      return Promise.resolve();
    }
    return this.identity.setMarketingConsent(consent);
  }

  /** Without consent the choice is only stored; it is sent once push starts. */
  setPushOptIn(optIn: boolean): Promise<void> {
    if (this.waitingForConsent) return this.platform.storage.setItem(PUSH_OPT_IN_KEY, String(optIn)).catch(() => undefined);
    return this.push.setPushOptIn(optIn);
  }

  /** Without consent this only shows the OS dialog; the result is reported once consent is given. */
  async requestPermission(): Promise<OsPermission> {
    if (this.waitingForConsent) return (await this.platform.notifications?.requestPermission()) ?? "undetermined";
    return this.push.requestPermission();
  }

  onNotificationOpened(cb: NotificationOpenedCallback): () => void {
    return this.push.onNotificationOpened(cb);
  }

  getInstallationId(): string | null {
    return this.installation.installationId;
  }

  rotateCredential(): Promise<void> {
    if (this.waitingForConsent) return Promise.resolve();
    return this.installation.rotate().then(() => undefined);
  }

  /** Stop timers and listeners (tests, hot reload). */
  destroy(): void {
    this.events.stop();
    this.push.stop();
  }
}
